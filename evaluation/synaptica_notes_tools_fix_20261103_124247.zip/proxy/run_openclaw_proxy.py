#!/usr/bin/env python3
"""
OpenAI-совместимый прокси-адаптер перед GigaChat IFT.

Зачем:
    Клиенты вроде OpenClaw (Cline / Continue / Aider / любой OpenAI-совместимый
    SDK) умеют ходить по OpenAI Chat Completions. GigaChat — близкий, но не
    идентичный контракт. Этот файл предоставляет OpenAI-совместимый
    `/v1/chat/completions` и `/v1/models` и под капотом транслирует запросы
    в GigaChat (`{base}/api/v1/...`).

Поддерживается:
    * tools / tool_choice (включая legacy `function_call` -> `tool_calls`);
    * стриминг (SSE);
    * mTLS до GigaChat (клиентские сертификаты);
    * получение и автообновление access_token через OAuth ("Authorization key");
    * подмена непонятной GigaChat'у модели на DEFAULT_MODEL.

Запуск:
    python run_openclaw_proxy.py --host 127.0.0.1 --port 9111

В OpenClaw указывайте:
    base URL: http://127.0.0.1:9111/v1
    api key:  любой непустой (или совпадающий с PROXY_API_KEY, если задан)

{
  "models": {
    "providers": {
      "deepSeek": {
        "api": "openai-completions",
        "apikey": "dummy",
        "baseURL": "http://127.0.0.1:9111/v1",
        "models": [
          {
            "id": "Qwen3.6-35b",
            "name": "Qwen3.6-35b",
            "contextWindow": 262144,
            "maxTokens": 32768,
            "reasoning": true,
            "compat": {
              "supportsTools": true,
              "supportsDeveloperRole": false
            }
          },
          {
            "id": "DeepSeek-V3.2",
            "name": "DeepSeek-V3.2",
            "contextWindow": 163840,
            "maxTokens": 32768,
            "reasoning": true,
            "compat": {
              "supportsTools": true,
              "supportsDeveloperRole": false
            }
          },
          {
            "id": "Qwen3.6-35b",
            "name": "Qwen3.6-35b",
            "contextWindow": 262144,
            "maxTokens": 32768,
            "reasoning": true,
            "compat": {
              "supportsTools": true,
              "supportsDeveloperRole": false
            }
          },
          {
            "id": "MiniMax-M2.7",
            "name": "MiniMax-M2.7",
            "contextWindow": 204800,
            "maxTokens": 32768,
            "reasoning": true,
            "compat": {
              "supportsTools": true,
              "supportsDeveloperRole": false
            }
          },
          {
            "id": "GLM-5.1",
            "name": "GLM-5.1",
            "contextWindow": 131072,
            "maxTokens": 32768,
            "reasoning": true,
            "compat": {
              "supportsTools": true,
              "supportsDeveloperRole": false
            }
          }
        ]
      }
    }
  }
}

ps -ef | grep -E 'openclaw|gateway' | grep -v grep
Найди PID, kill <pid>, потом запусти gateway заново той же командой, что и раньше (openclaw gateway --port 18789 или подобное).

curl -s http://127.0.0.1:9111/health


ENV-переменные (все опциональные, подставлены безопасные дефолты):

    # Куда ходим
    GIGACHAT_BASE_URL          по умолчанию https://gigachat-ift.sberdevices.delta.sbrf.ru
    GIGACHAT_API_PREFIX        по умолчанию /api/v1   (для IFT может быть /v1)
    DEFAULT_MODEL              по умолчанию GigaChat-Pro

    # Аутентификация в GigaChat

    # mTLS / TLS
    GIGACHAT_CERT              путь к клиентскому сертификату (.crt / chain pem)
    GIGACHAT_KEY               путь к приватному ключу (.key / pem)
    GIGACHAT_ROOT              путь к корневому CA для проверки сервера
    VERIFY_SSL                 false, чтобы отключить проверку (на свой риск)

    # Безопасность самого прокси
    PROXY_API_KEY              если задан — клиент обязан слать Bearer == ему
    REQUEST_TIMEOUT            секунды, по умолчанию 60
    STREAM_TIMEOUT             секунды, по умолчанию 600

    # Консольный лог (полный дамп по-прежнему в DEBUG_DUMP_FILE)
    PROXY_ACCESS_LOG           true — строки [chat]/[stream]/[response] с agent=model=...
    STREAM_CHUNK_LOG           true — лог каждого SSE-чанка (шумно)
    STALL_WARN_SECONDS         каждые N сек тишины от upstream — строка [wait] (0 = выкл), по умолчанию 20
    DEBUG_BODY                 true — печатать целиком upstream <- / ->
"""

from __future__ import annotations

import argparse
import asyncio
import contextvars
import json
import logging
import os
import re
import ssl
import time
import uuid
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, AsyncIterator, Mapping, Optional

import httpx
import uvicorn
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse, Response, StreamingResponse


# ---------------------------------------------------------------------------
# Конфиг
# ---------------------------------------------------------------------------


def _env_bool(name: str, default: bool = False) -> bool:
    raw = os.getenv(name)
    if raw is None:
        return default
    return raw.strip().lower() in {"1", "true", "yes", "y", "on"}


class Settings:
    """
    Дефолты заданы под IFT-окружение, как в `_make_giga()` проекта:
        base_url=https://gigachat-ift.sberdevices.delta.sbrf.ru/v1/
        cert_file=/tmp/giga/giga_cert.pem
        key_file =/tmp/giga/giga_key.key
        model    =Qwen3.6-35b
        model    =Qwen3.6-35b

    Любое поле можно перебить переменной окружения с тем же именем.
    Аутентификация — через mTLS (клиентский сертификат), Bearer не нужен.
    """

    BASE_URL: str = os.getenv("GIGACHAT_BASE_URL", "https://gigachat-ift.sberdevices.delta.sbrf.ru").rstrip("/")
    API_PREFIX: str = "/" + os.getenv("GIGACHAT_API_PREFIX", "/v1").strip("/")
    DEFAULT_MODEL: str = os.getenv("DEFAULT_MODEL", "Qwen3.6-35b")

    ACCESS_TOKEN: Optional[str] = os.getenv("GIGACHAT_ACCESS_TOKEN") or None
    AUTH_KEY: Optional[str] = os.getenv("GIGACHAT_AUTH_KEY") or None
    OAUTH_SCOPE: str = os.getenv("GIGACHAT_SCOPE", "GIGACHAT_API_CORP")
    OAUTH_URL: str = os.getenv(
        "GIGACHAT_OAUTH_URL",
        os.getenv("GIGACHAT_BASE_URL", "https://gigachat-ift.sberdevices.delta.sbrf.ru").rstrip("/") + "/api/v2/oauth",
    )

    # mTLS-сертификаты: пути взяты прямо из `_make_giga()` проекта.
    cert: str = os.getenv("GIGACHAT_CERT", "/tmp/giga/giga_cert.pem")
    key: str = os.getenv("GIGACHAT_KEY", "/tmp/giga/giga_key.key")
    ROOT_CA: Optional[str] = os.getenv("GIGACHAT_ROOT") or None
    # В `_make_giga` корневой CA не передаётся — оставим проверку выключенной
    # по умолчанию, чтобы не словить ошибку доверия. Включи через VERIFY_SSL=true,
    # если задан валидный GIGACHAT_ROOT.
    VERIFY_SSL: bool = _env_bool("VERIFY_SSL", default=False)

    # Если пусто — клиентский Authorization НЕ пробрасывается в GigaChat
    # (OpenClaw часто шлёт "Bearer dummy", а IFT этого не любит — авторизация
    #  идёт mTLS-сертификатом).
    FORWARD_CLIENT_AUTH: bool = _env_bool("FORWARD_CLIENT_AUTH", default=False)

    # Любая модель, не входящая в список GigaChat, заменяется на DEFAULT_MODEL.
    # Без этого OpenClaw отправляет id типа "DeepSeek-R1"/"claude-..." и
    # апстрим отвечает 404 "No such model".
    FORCE_MODEL: bool = _env_bool("FORCE_MODEL", default=True)
    KNOWN_MODELS_RAW: str = os.getenv(
        "GIGACHAT_KNOWN_MODELS",
        # GigaChat-* — для штатной работы OpenClaw (это его специфика).
        "GigaChat,GigaChat-Plus,GigaChat-Pro,GigaChat-Max,"
        "GigaChat-2,GigaChat-2-Pro,GigaChat-2-Max,"
        "GigaChat-3,GigaChat-3-Pro,GigaChat-3-Max,"
        # Open-weights через IFT — добавлены под новые модели.
        "Qwen3.6-35b,Qwen3.5-397b,"
        "DeepSeek-V3.2,"
        "MiniMax-M2.7,"
        "GLM-5.1",
    )

    @classmethod
    def known_models(cls) -> set[str]:
        return {m.strip() for m in cls.KNOWN_MODELS_RAW.split(",") if m.strip()}

    # Список моделей, который прокси сам возвращает в `/v1/models` (то, что
    # клиент покажет в выпадающем списке выбора модели).
    EXPOSED_MODELS_RAW: str = os.getenv(
        "EXPOSED_MODELS",
        "Qwen3.6-35b,Qwen3.5-397b,DeepSeek-V3.2,MiniMax-M2.7,GLM-5.1",
    )

    @classmethod
    def exposed_models(cls) -> list[str]:
        """Список моделей, который вернётся в `/v1/models` (порядок сохраняется)."""
        return [m.strip() for m in cls.EXPOSED_MODELS_RAW.split(",") if m.strip()]

    # Дополнительно дёргать upstream `/v1/models` и подмешивать его список к
    # нашему. По умолчанию выключено — IFT-список длинный и содержит модели,
    # которые мы не поддерживаем. Включи, если хочешь видеть в UI ещё и
    # GigaChat-* модели.
    MODELS_FETCH_UPSTREAM: bool = _env_bool("MODELS_FETCH_UPSTREAM", default=False)

    # OpenAI tool_choice="required" GigaChat нативно не понимает.
    # По умолчанию приводим к "auto"; включи STRICT_TOOL_CHOICE=true, чтобы
    # отправлять как есть и проверить, держит ли это конкретная сборка GigaChat.
    STRICT_TOOL_CHOICE: bool = _env_bool("STRICT_TOOL_CHOICE", default=True)

    # Если модель отказывается возвращать `tool_calls` в новом формате,
    # включи LEGACY_FUNCTIONS=true: tools[] -> functions[], tool_choice -> function_call.
    # Часть GigaChat-сборок реагирует только на legacy-схему.
    LEGACY_FUNCTIONS: bool = _env_bool("LEGACY_FUNCTIONS", default=True)

    # Для thinking-моделей (Qwen3, DeepSeek-R1 и т.п.) почти всегда нужен
    # современный `tools`/`tool_choice`/`tool_calls` формат. Иначе модель не
    # видит инструменты вообще и просто отвечает текстом «вызову X», но
    # ничего не делает (см. OpenClaw issues #1866, #8923, #41328).
    # Если оставить True — для thinking-моделей будет использоваться новый
    # формат даже когда `LEGACY_FUNCTIONS=true` глобально.
    THINKING_USE_NEW_TOOLS: bool = _env_bool("THINKING_USE_NEW_TOOLS", default=True)

    # Сохранять в исходящем JSON нативные assistant.tool_calls + role:tool.
    # IFT для Qwen3 на втором круге (после выполнения тула) часто отвечает
    # 422 "unsupported role function" — бэкенд не принимает эти роли в
    # messages. Поэтому по умолчанию False: история сворачивается через
    # INLINE_TOOL_HISTORY (текстом), а в payload по-прежнему уходит
    # современный массив `tools`.
    THINKING_NATIVE_TOOL_HISTORY: bool = _env_bool(
        "THINKING_NATIVE_TOOL_HISTORY", default=False
    )

    # Удаляет `strict: true` из tool definitions перед отправкой upstream.
    # Многие OpenAI-совместимые провайдеры (включая Alibaba/Bailian/Qwen)
    # тихо роняют tools со strict-флагом, см. OpenClaw PR #41457.
    STRIP_TOOL_STRICT: bool = _env_bool("STRIP_TOOL_STRICT", default=True)

    # Дописывает в system-промпт human-readable каталог доступных тулзов
    # (имя + описание + JSON-схема параметров) для thinking-моделей.
    # Это критично для Qwen-через-IFT: IFT для не-GigaChat моделей режет
    # `tools` из payload, и без явного каталога модель «не видит»
    # инструменты и пишет действия прозой вместо <tool_call>.
    INJECT_TOOL_CATALOG: bool = _env_bool("INJECT_TOOL_CATALOG", default=True)

    # Обрезка длинной истории: оставляем последние N сообщений (system не считается).
    # 0 — без обрезки.
    MAX_HISTORY_MESSAGES: int = int(os.getenv("MAX_HISTORY_MESSAGES", "15"))

    # Склеивать подряд идущие сообщения с одинаковой ролью (user/user или
    # assistant/assistant). GigaChat требует чередования user<->assistant
    # и валит запрос ошибкой 400 "invalid JSON syntax", если это нарушено.
    MERGE_CONSECUTIVE_ROLES: bool = _env_bool("MERGE_CONSECUTIVE_ROLES", default=True)

    # Полностью убирать из истории tool/function сообщения и assistant с
    # function_call/tool_calls. Помогает, когда предыдущие вызовы инструментов
    # падали и шум ломает дальнейшие запросы.
    STRIP_TOOL_HISTORY: bool = _env_bool("STRIP_TOOL_HISTORY", default=False)

    # Превращать историю tool-вызовов в обычный текстовый диалог
    # assistant/user: assistant.function_call -> текстовое описание вызова,
    # role=function/tool -> user-сообщение с результатом.
    # GigaChat IFT не принимает legacy `function_call`/`function` в request
    # messages (валит 400 "invalid JSON syntax"), но сами `functions` для
    # вызова инструментов поддерживает. Инлайн позволяет модели «помнить»
    # предыдущие вызовы, не нарушая формат запроса.
    INLINE_TOOL_HISTORY: bool = _env_bool("INLINE_TOOL_HISTORY", default=True)

    # Удалять из истории ТОЛЬКО неуспешные tool-ответы (status:error, "Missing
    # required parameter", <empty-string> и т.п.) вместе с породившим их
    # assistant.function_call. Чистые успешные tool-обмены остаются — модель
    # видит пример вызова инструмента и продолжает их звать.
    DROP_FAILED_TOOL_RESULTS: bool = _env_bool("DROP_FAILED_TOOL_RESULTS", default=True)

    # При 400 "invalid JSON syntax" автоматически повторить запрос со снятой
    # tool-историей. Прозрачно для клиента (включая стрим).
    RETRY_STRIP_ON_400: bool = _env_bool("RETRY_STRIP_ON_400", default=True)

    # Дополнительный текст, который дописывается в конец первого system-сообщения.
    # Нужен, чтобы поправить поведение конкретной модели (Qwen3.6-35b
    # Нужен, чтобы поправить поведение конкретной модели (Qwen3.6-35b
    # упорно зовёт sessions_spawn для knowledge-скиллов и теряет результат).
    # Если переменная пустая — ничего не дописываем.
    EXTRA_SYSTEM_HINT: str = os.getenv(
        "EXTRA_SYSTEM_HINT",
        (
            "## Proxy hint: tool usage discipline\n"
            "Items listed under `<available_skills>` are KNOWLEDGE packages "
            "(a directory with SKILL.md). They are NOT sub-agents and NOT "
            "ACP harnesses — calling `sessions_spawn` with such a name as "
            "`agentId` will silently fail and trigger a retry loop.\n"
            "- DO NOT call `sessions_spawn` with `agentId` set to a skill "
            "name (e.g. `skill-creator`, `taskflow`, `finrag`).\n"
            "- BEFORE calling `sessions_spawn`, call the `agents_list` tool "
            "and pick `agentId` only from its output.\n"
            "- This installation has NO ACP harnesses paired (`openclaw acp` "
            "returns `pairing required`), so `runtime: \"acp\"` is currently "
            "unavailable. Use `runtime: \"subagent\"` instead, with an id "
            "from `agents_list`.\n"
            "- To CREATE/EDIT/AUDIT a skill: read the relevant SKILL.md and "
            "use `read`/`write`/`edit`/`exec` directly to author the files "
            "yourself. Do not delegate.\n"
            "- Never repeat the exact same tool call with identical arguments "
            "more than once. If the previous attempt produced no observable "
            "result, switch tactic or reply to the user."
        ),
    )

    # ---- Поддержка thinking-моделей (Qwen3, DeepSeek-R1 и т.п.) ----------
    # Скрываем от клиента содержимое блоков `<think>...</think>` (а также
    # `<reasoning>...</reasoning>`). Клиент видит только финальный ответ
    # модели после закрывающего тега, что соответствует поведению
    # «модель думает, но показывает только ответ».
    HIDE_THINK_BLOCKS: bool = _env_bool("HIDE_THINK_BLOCKS", default=True)

    # Вместо того чтобы просто выкидывать содержимое `<think>` блоков, отдаём
    # его клиенту как отдельное поле `reasoning_content` (в `delta.reasoning_content`
    # для стрима и `message.reasoning_content` для non-stream). Это нативный
    # контракт `@ai-sdk/openai-compatible` (используется OpenCode/AI SDK и
    # DeepSeek-R1-клиентами): они подхватывают это поле и рендерят его как
    # раскрывающийся блок «Thinking…». Работает только когда
    # HIDE_THINK_BLOCKS=True и модель определена как thinking.
    EMIT_REASONING_CONTENT: bool = _env_bool("EMIT_REASONING_CONTENT", default=True)

    # Часть клиентов (через AI SDK) при ведении диалога с reasoning-моделями
    # кладёт reasoning в историю отдельными сообщениями с нестандартной
    # ролью `assistant_thinking` (или похожей с суффиксом `_thinking`),
    # а также может оставлять поле `reasoning_content` на assistant-сообщениях.
    # GigaChat IFT таких ролей/полей не знает и валит запрос ошибкой
    # `422 Invalid params: unsupported role assistant_thinking`.
    # Этот флаг вырезает их из истории на пути в апстрим.
    STRIP_REASONING_HISTORY: bool = _env_bool("STRIP_REASONING_HISTORY", default=True)

    # Дополнительно вырезаем `<think>...</think>` из ИСХОДЯЩИХ messages.content
    # (то, что клиент шлёт обратно как часть истории). Иначе прошлые «думанья»
    # модели накапливаются в каждом запросе и съедают весь контекст.
    STRIP_THINK_FROM_HISTORY: bool = _env_bool("STRIP_THINK_FROM_HISTORY", default=True)

    # Минимальный `max_tokens`, который мы гарантируем для thinking-моделей.
    # Если клиент не задал `max_tokens` (или задал меньше) — поднимаем до этого
    # значения, чтобы у модели хватило бюджета на reasoning + ответ.
    # 0 = ничего не делать.
    MIN_MAX_TOKENS_THINKING: int = int(os.getenv("MIN_MAX_TOKENS_THINKING", "32768"))

    # Регэксп имён моделей, для которых считаем модель «thinking».
    # Ловим: qwen3.x, deepseek-r1 / deepseek-v3.2 (имеет thinking-режим),
    # minimax (M-серия — reasoning-модель), glm-4.5+/5.x (reasoning),
    # o1/o3, и явные пометки `thinking`.
    THINKING_MODEL_REGEX: str = os.getenv(
        "THINKING_MODEL_REGEX",
        r"(?i)("
        r"qwen[-_]?3(?:\.\d+)?"            # Qwen3, Qwen3.5
        r"|deepseek[-_ ]?(?:r1|v3(?:\.\d+)?)"  # DeepSeek-R1 / V3 / V3.2
        r"|(?<!\w)r1(?!\w)"
        r"|minimax(?:[-_ ]?m\d+(?:\.\d+)?)?"   # MiniMax / MiniMax-M2.7
        r"|glm[-_]?(?:[4-9]|\d{2,})(?:\.\d+)?"  # glm-4.5+, glm-5.x
        r"|o[13](?:-|$)"
        r"|thinking"
        r")",
    )

    # Дополнительная инструкция для thinking-моделей. Лечит:
    # 1. Они часто пишут «я вызову tool X» в markdown вместо реального tool_call.
    # 2. После Pre-compaction memory flush повадятся отвечать "NO_REPLY"
    #    вообще на всё подряд, включая прямые просьбы пользователя.
    # 3. Описывает строгий формат `<tool_call>` для prompt-based fallback,
    #    когда upstream вообще не поддерживает native function-calling.
    EXTRA_THINKING_HINT: str = os.getenv(
        "EXTRA_THINKING_HINT",
        (
            "## Behaviour rules (proxy-enforced)\n"
            "- When the user asks you to DO something (run a command, create "
            "a file, spawn a sub-agent, edit code, etc.) — invoke an "
            "available tool. Prefer native tool calling when supported; "
            "otherwise follow the EXACT tool-call syntax in the model-specific "
            "tool catalog above. Do NOT describe in plain text "
            "what you are going to call; the user cannot execute that for "
            "you. Markdown like `read(path=...)`, ```bash code blocks, etc. "
            "will NOT be executed.\n"
            "- Use ONLY tool names from the tool catalog above, exactly as "
            "spelled (case-sensitive). Follow its argument encoding: JSON "
            "arguments must be a valid object, without comments, trailing "
            "commas, or Python literals; XML arguments must follow its tags.\n"
            "- Do NOT wrap tool calls in backticks or markdown fences. "
            "Do NOT substitute another model family's tool-call format.\n"
            "- You may emit multiple tool calls in one turn. After emitting "
            "them, STOP and wait "
            "for the tool results — do NOT invent results.\n"
            "- If a previous tool call returned an error (file not "
            "found, permission denied, command not found, etc.) — DO NOT "
            "give up and DO NOT fall back to printing the command as "
            "plain text or a ```bash code block. Analyze the error, fix "
            "the arguments (typical fixes: correct path, missing flags, "
            "wrong working directory, call `ls`/`pwd` first to orient) "
            "and retry with another tool call in the catalog's format.\n"
            "- `NO_REPLY` is reserved for system maintenance messages like "
            "`Pre-compaction memory flush`. NEVER reply `NO_REPLY` to a "
            "regular user message — even a short one like 'да', 'сделай', "
            "'ок'. If a user message arrives, you MUST either answer in "
            "plain text or call a tool.\n"
            "- Keep your hidden `<think>` reasoning short. The user only "
            "sees the final answer; long reasoning wastes the context "
            "window."
        ),
    )

    # Подробное логирование тел запросов/ответов (без секретов в заголовках).
    # По умолчанию выкл.: полный трафик остаётся в DEBUG_DUMP_FILE.
    DEBUG_BODY: bool = _env_bool("DEBUG_BODY", default=False)
    DEBUG_BODY_LIMIT: int = int(os.getenv("DEBUG_BODY_LIMIT", "2000"))  # 0 = без обрезки

    # Читаемый журнал в консоли: агент OpenClaw, краткий user, итог стрима.
    PROXY_ACCESS_LOG: bool = _env_bool("PROXY_ACCESS_LOG", default=True)
    # Логировать каждый SSE-чанк (очень шумно; полный стрим в DEBUG_DUMP_FILE).
    STREAM_CHUNK_LOG: bool = _env_bool("STREAM_CHUNK_LOG", default=False)
    # Сколько секунд тишины от upstream (нет заголовков / первого токена /
    # следующего чанка) до предупреждения [wait]; повторяется каждые N сек.
    STALL_WARN_SECONDS: float = float(os.getenv("STALL_WARN_SECONDS", "20"))

    # Параллельно с обычным логом писать дампы каждого взаимодействия
    # в указанный файл — удобно прислать целиком для разбора.
    DEBUG_DUMP_FILE: Optional[str] = "openclaw_proxy_dump.log"
    # Компактный режим: длинные system-промпты и описания tool'ов сворачиваются
    # до коротких сводок, в стрим-чанках убираем повторяющиеся служебные поля.
    DEBUG_DUMP_COMPACT: bool = _env_bool("DEBUG_DUMP_COMPACT", default=True)
    # Сколько символов оставлять от system-промпта при компакт-дампе.
    DEBUG_DUMP_SYSTEM_HEAD: int = int(os.getenv("DEBUG_DUMP_SYSTEM_HEAD", "300"))

    PROXY_API_KEY: Optional[str] = os.getenv("PROXY_API_KEY") or None
    REQUEST_TIMEOUT: float = float(os.getenv("REQUEST_TIMEOUT", "60"))
    STREAM_TIMEOUT: float = float(os.getenv("STREAM_TIMEOUT", "600"))

    # При 429 (rate limit) от upstream: сколько раз повторить и начальная пауза (сек).
    # Пауза удваивается с каждой попыткой: 5s → 10s → 20s → ...
    RETRY_429_MAX_ATTEMPTS: int = int(os.getenv("RETRY_429_MAX_ATTEMPTS", "4"))
    RETRY_429_INITIAL_DELAY: float = float(os.getenv("RETRY_429_INITIAL_DELAY", "5"))

    # Retry на СЕТЕВЫХ ошибках до upstream (httpx.ConnectError /
    # ConnectTimeout / ReadTimeout / RemoteProtocolError и т.п.) — TCP
    # ещё не открылся или оборвался на TLS-handshake. На практике IFT
    # такое периодически делает (особенно в часы пик), и без ретрая
    # пользователь видит мгновенное падение запроса. Пауза экспоненциально
    # удваивается: 1s → 2s → 4s → ...
    RETRY_NETWORK_MAX_ATTEMPTS: int = int(os.getenv("RETRY_NETWORK_MAX_ATTEMPTS", "3"))
    RETRY_NETWORK_INITIAL_DELAY: float = float(os.getenv("RETRY_NETWORK_INITIAL_DELAY", "1"))


# Короткий id входящего запроса — в каждой строке лога, чтобы разводить
# параллельные запросы OpenClaw.
_request_id: contextvars.ContextVar[str] = contextvars.ContextVar("request_id", default="-")


class _RequestIdFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        record.rid = _request_id.get()
        return True


logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s [%(rid)s] :: %(message)s",
)
for _handler in logging.getLogger().handlers:
    _handler.addFilter(_RequestIdFilter())
log = logging.getLogger("openclaw-proxy")

# ── Tool events JSONL (для Streamlit UI) ────────────────────────────────────
TOOL_EVENTS_FILE: str = os.getenv("TOOL_EVENTS_FILE", "/tmp/openclaw-tools.jsonl")
_tool_events_lock = __import__("threading").Lock()
# Лимит обрезки `detail` в JSONL (символы). 0 = без обрезки. По умолчанию
# 50 000 — чтобы Streamlit мог восстанавливать полные ответы tool (raw_text
# заметок FI и т.п.) и рисовать раскрывающиеся карточки источников.
TOOL_EVENT_DETAIL_LIMIT: int = int(os.getenv("TOOL_EVENT_DETAIL_LIMIT", "50000"))


def _write_tool_event(agent: str, event: str, tool: str, detail: str = "") -> None:
    """Пишет одну строку JSONL: ts / agent / event / tool / detail."""
    payload = detail or ""
    if TOOL_EVENT_DETAIL_LIMIT > 0 and len(payload) > TOOL_EVENT_DETAIL_LIMIT:
        payload = payload[:TOOL_EVENT_DETAIL_LIMIT]
    row = json.dumps(
        {"ts": time.time(), "agent": agent, "event": event, "tool": tool, "detail": payload},
        ensure_ascii=False,
    )
    try:
        with _tool_events_lock:
            with open(TOOL_EVENTS_FILE, "a", encoding="utf-8") as fh:
                fh.write(row + "\n")
    except Exception:
        pass


def _detect_tool_calls_in_chunk(chunk: dict[str, Any]) -> list[tuple[str, str]]:
    """Возвращает [(name, args_so_far)] для function_call/tool_calls в чанке."""
    found: list[tuple[str, str]] = []
    for choice in chunk.get("choices") or []:
        delta = choice.get("delta") or {}
        fc = delta.get("function_call")
        if isinstance(fc, dict) and fc.get("name"):
            found.append((fc["name"], fc.get("arguments", "") or ""))
        for tc in delta.get("tool_calls") or []:
            fn = (tc.get("function") or {}) if isinstance(tc, dict) else {}
            if fn.get("name"):
                found.append((fn["name"], fn.get("arguments", "") or ""))
    return found


def _detect_tool_results_in_messages(messages: list[dict[str, Any]]) -> list[tuple[str, str]]:
    """[(name, content)] для role=tool/function — до transform_request."""
    results: list[tuple[str, str]] = []
    limit = TOOL_EVENT_DETAIL_LIMIT
    for msg in messages or []:
        if not isinstance(msg, dict):
            continue
        role = msg.get("role", "")
        if role not in ("tool", "function"):
            continue
        name = msg.get("name") or "tool"
        content = str(msg.get("content") or "")
        if limit > 0 and len(content) > limit:
            content = content[:limit]
        results.append((name, content))
    return results


def _truncate(text: str) -> str:
    """Обрезает текст до DEBUG_BODY_LIMIT символов; 0 — без обрезки."""
    limit = Settings.DEBUG_BODY_LIMIT
    if limit and len(text) > limit:
        return text[:limit] + f"... [truncated, full {len(text)} chars]"
    return text


def _summarize_text(text: str, head: int) -> str:
    """Возвращает префикс длиной `head` плюс хвостовую сводку с длиной."""
    if head <= 0 or len(text) <= head:
        return text
    return text[:head] + f"... <+{len(text) - head} chars>"


def _compact_request_payload(payload: Mapping[str, Any]) -> dict[str, Any]:
    """Свёрнутая копия REQUEST-payload для компактного дампа."""
    head = Settings.DEBUG_DUMP_SYSTEM_HEAD
    out: dict[str, Any] = {
        "model": payload.get("model"),
        "stream": payload.get("stream"),
    }
    if "tool_choice" in payload:
        out["tool_choice"] = payload["tool_choice"]
    if "function_call" in payload:
        out["function_call"] = payload["function_call"]

    msgs = payload.get("messages")
    if isinstance(msgs, list):
        compact_msgs: list[Any] = []
        for msg in msgs:
            if not isinstance(msg, dict):
                compact_msgs.append(msg)
                continue
            new_msg = dict(msg)
            content = new_msg.get("content")
            if new_msg.get("role") == "system" and isinstance(content, str):
                new_msg["content"] = _summarize_text(content, head)
            elif isinstance(content, str) and len(content) > 4000:
                new_msg["content"] = _summarize_text(content, 4000)
            compact_msgs.append(new_msg)
        out["messages"] = compact_msgs
        out["_messages_count"] = len(compact_msgs)

    for tools_key in ("tools", "functions"):
        tools = payload.get(tools_key)
        if isinstance(tools, list):
            names: list[str] = []
            for tool in tools:
                if not isinstance(tool, dict):
                    continue
                if tools_key == "tools":
                    fn = tool.get("function") or {}
                    name = fn.get("name") if isinstance(fn, dict) else None
                else:
                    name = tool.get("name")
                if name:
                    names.append(str(name))
            out[f"_{tools_key}_names"] = names
    return out


def _compact_stream_chunk(chunk: Any) -> Any:
    """Оставляет в стрим-чанке только то, что меняется turn-to-turn."""
    if not isinstance(chunk, dict):
        return chunk
    choices = chunk.get("choices")
    if not isinstance(choices, list):
        return chunk
    compact_choices: list[Any] = []
    for choice in choices:
        if not isinstance(choice, dict):
            compact_choices.append(choice)
            continue
        cc: dict[str, Any] = {}
        if "index" in choice:
            cc["index"] = choice["index"]
        delta = choice.get("delta")
        if isinstance(delta, dict):
            d: dict[str, Any] = {}
            for k in ("role", "content", "tool_calls", "function_call"):
                if k in delta and delta[k] not in (None, "", []):
                    d[k] = delta[k]
            if d:
                cc["delta"] = d
        if choice.get("finish_reason"):
            cc["finish_reason"] = choice["finish_reason"]
        compact_choices.append(cc)
    return {"choices": compact_choices}


def _compact_for_dump(label: str, payload: Any) -> Any:
    """Свёрнутый payload для компактного дампа в DEBUG_DUMP_FILE."""
    if not Settings.DEBUG_DUMP_COMPACT or not isinstance(payload, (dict, list)):
        return payload
    if label.startswith("REQUEST -> upstream") and isinstance(payload, dict):
        return _compact_request_payload(payload)
    if label.startswith("STREAM CHUNKS") and isinstance(payload, list):
        return [_compact_stream_chunk(chunk) for chunk in payload]
    if label.startswith("RESPONSE") and isinstance(payload, dict):
        # У single-shot ответа повторяются те же служебные поля, что и в стриме.
        compact = dict(payload)
        for big in ("additional_data",):
            compact.pop(big, None)
        return compact
    return payload


def _dump_to_file(label: str, payload: Any) -> None:
    """Пишет JSON-дамп в DEBUG_DUMP_FILE; в компакт-режиме сворачивает шум."""
    path = Settings.DEBUG_DUMP_FILE
    if not path:
        return
    try:
        compact = _compact_for_dump(label, payload)
        if isinstance(compact, (dict, list)):
            body = json.dumps(compact, ensure_ascii=False, indent=2)
        else:
            body = str(compact)
        ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S.%f")
        with open(path, "a", encoding="utf-8") as f:
            f.write(f"\n===== {ts} :: {label} =====\n{body}\n")
    except Exception as exc:
        log.warning("dump failed (%s): %s", label, exc)


# ---------------------------------------------------------------------------
# HTTP-клиент к GigaChat (mTLS)
# ---------------------------------------------------------------------------


def build_http_client() -> httpx.AsyncClient:
    kwargs: dict[str, Any] = {
        "timeout": httpx.Timeout(Settings.REQUEST_TIMEOUT),
        "follow_redirects": True,
    }

    if not Settings.VERIFY_SSL:
        kwargs["verify"] = False
        log.warning("SSL verification disabled")
    elif Settings.ROOT_CA and Path(Settings.ROOT_CA).exists():
        kwargs["verify"] = Settings.ROOT_CA
    else:
        kwargs["verify"] = True

    if Settings.cert and Settings.key and Path(Settings.cert).exists() and Path(Settings.key).exists():
        kwargs["cert"] = (Settings.cert, Settings.key)
        log.info("Using client certificate: %s", Settings.cert)

    return httpx.AsyncClient(**kwargs)


# ---------------------------------------------------------------------------
# Менеджер OAuth-токена GigaChat
# ---------------------------------------------------------------------------


class TokenManager:
    """
    Источник Bearer-токена для исходящих запросов в GigaChat.

    Приоритет:
        1) фиксированный ACCESS_TOKEN из ENV;
        2) обмен AUTH_KEY -> access_token через OAuth с автообновлением;
        3) клиентский Authorization (только если FORWARD_CLIENT_AUTH=true);
        4) None -> авторизация только mTLS-сертификатом (по умолчанию для IFT).
    """

    def __init__(self, client: httpx.AsyncClient) -> None:
        self._client = client
        self._lock = asyncio.Lock()
        self._token: Optional[str] = Settings.ACCESS_TOKEN
        self._expires_at: float = float("inf") if Settings.ACCESS_TOKEN else 0.0

    async def get(self, fallback_authorization: Optional[str]) -> Optional[str]:
        if Settings.ACCESS_TOKEN:
            return f"Bearer {Settings.ACCESS_TOKEN}"

        if Settings.AUTH_KEY:
            async with self._lock:
                if not self._token or time.time() >= self._expires_at - 30:
                    await self._refresh()
            return f"Bearer {self._token}" if self._token else None

        if Settings.FORWARD_CLIENT_AUTH:
            return fallback_authorization

        return None

    async def _refresh(self) -> None:
        rq_uid = str(uuid.uuid4())
        headers = {
            "Authorization": f"Basic {Settings.AUTH_KEY}",
            "RqUID": rq_uid,
            "Content-Type": "application/x-www-form-urlencoded",
            "Accept": "application/json",
        }
        data = {"scope": Settings.OAUTH_SCOPE}

        log.info("Refreshing GigaChat access_token via %s (scope=%s)", Settings.OAUTH_URL, Settings.OAUTH_SCOPE)
        resp = await self._client.post(Settings.OAUTH_URL, headers=headers, data=data)
        if resp.status_code >= 400:
            log.error("OAuth failed: %s %s", resp.status_code, resp.text[:500])
            resp.raise_for_status()

        payload = resp.json()
        self._token = payload.get("access_token")
        expires_at_ms = payload.get("expires_at") or 0
        if expires_at_ms:
            self._expires_at = float(expires_at_ms) / 1000.0
        else:
            self._expires_at = time.time() + 25 * 60


# ---------------------------------------------------------------------------
# Маппинг OpenAI <-> GigaChat
# ---------------------------------------------------------------------------


# Поля, которые GigaChat надёжно понимает.  Остальные тихо отбрасываем,
# чтобы не получать 4xx из-за неизвестного параметра.
_ALLOWED_REQUEST_FIELDS: frozenset[str] = frozenset(
    {
        "model",
        "messages",
        "temperature",
        "top_p",
        "max_tokens",
        "stream",
        "stop",
        "n",
        "tools",
        "tool_choice",
        "function_call",
        "functions",
        "repetition_penalty",
        "update_interval",
        "profanity_check",
    }
)


def _stringify_content(content: Any) -> str:
    """OpenAI multimodal content[] / None -> str (GigaChat не любит null/array)."""
    if content is None:
        return ""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: list[str] = []
        for block in content:
            if isinstance(block, dict) and block.get("type") == "text":
                parts.append(str(block.get("text", "")))
            elif isinstance(block, str):
                parts.append(block)
        return "\n\n".join(p for p in parts if p)
    return str(content)


_RUNTIME_AGENT_RE = re.compile(r"Runtime:\s*agent=([^\s|\n]+)", re.IGNORECASE)


def _openclaw_context_from_messages(messages: Any) -> dict[str, str]:
    """Достаёт из system-промпта OpenClaw строку вида ``Runtime: agent=...``."""
    agent = ""
    if not isinstance(messages, list):
        return {"agent": agent}
    for raw in messages:
        if not isinstance(raw, dict) or raw.get("role") != "system":
            continue
        text = _stringify_content(raw.get("content"))
        m = _RUNTIME_AGENT_RE.search(text)
        if m:
            agent = m.group(1).strip()
            break
    return {"agent": agent}


def _last_user_preview(messages: Any, limit: int = 120) -> str:
    """Краткий текст последнего user-сообщения (для access-log)."""
    if not isinstance(messages, list):
        return ""
    for raw in reversed(messages):
        if not isinstance(raw, dict) or raw.get("role") != "user":
            continue
        s = _stringify_content(raw.get("content")).strip().replace("\n", " ")
        if len(s) > limit:
            return s[: limit - 3] + "..."
        return s
    return ""


def _finish_reason_from_chunks(chunks: list[dict[str, Any]]) -> str:
    for ch in reversed(chunks):
        if not isinstance(ch, dict):
            continue
        choices = ch.get("choices")
        if not isinstance(choices, list) or not choices:
            continue
        c0 = choices[0]
        if not isinstance(c0, dict):
            continue
        fr = c0.get("finish_reason")
        if fr:
            return str(fr)
    return ""


def _tool_names_from_chunks(chunks: list[dict[str, Any]]) -> list[str]:
    names: list[str] = []
    seen: set[str] = set()

    def _add(name: Any) -> None:
        if isinstance(name, str) and name and name not in seen:
            seen.add(name)
            names.append(name)

    for ch in chunks:
        if not isinstance(ch, dict):
            continue
        choices = ch.get("choices")
        if not isinstance(choices, list):
            continue
        for choice in choices:
            if not isinstance(choice, dict):
                continue
            delta = choice.get("delta")
            if isinstance(delta, dict):
                fc = delta.get("function_call")
                if isinstance(fc, dict):
                    _add(fc.get("name"))
                for tc in delta.get("tool_calls") or []:
                    if not isinstance(tc, dict):
                        continue
                    fn = tc.get("function")
                    if isinstance(fn, dict):
                        _add(fn.get("name"))
            msg = choice.get("message")
            if isinstance(msg, dict):
                for tc in msg.get("tool_calls") or []:
                    if not isinstance(tc, dict):
                        continue
                    fn = tc.get("function")
                    if isinstance(fn, dict):
                        _add(fn.get("name"))
    return names


def _normalize_messages(messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """
    Приводим историю к виду, который принимает GigaChat:
        * system-сообщения склеиваются и переносятся в начало;
        * content всегда строка (null/array -> str);
        * сообщения с нестандартной ролью `*_thinking` (AI SDK
          складывает туда reasoning-историю) отбрасываются — апстрим IFT
          валит запрос с `422 unsupported role assistant_thinking`;
        * поле `reasoning_content` на остальных сообщениях вырезается
          по той же причине;
        * остальное оставляем как есть (роли tool/assistant.tool_calls
          конвертирует уже _to_legacy_messages при включённом legacy-режиме).
    """
    if not isinstance(messages, list):
        return messages

    strip_reasoning = Settings.STRIP_REASONING_HISTORY

    system_parts: list[str] = []
    rest: list[dict[str, Any]] = []

    for raw in messages:
        if not isinstance(raw, dict):
            continue
        role = raw.get("role")

        if strip_reasoning and isinstance(role, str) and role.endswith("_thinking"):
            continue

        msg = dict(raw)
        if strip_reasoning:
            msg.pop("reasoning_content", None)
            msg.pop("reasoning", None)
        msg["content"] = _stringify_content(msg.get("content"))

        if msg.get("role") == "system":
            text = msg.get("content") or ""
            if text:
                system_parts.append(text)
            continue

        rest.append(msg)

    extra = (Settings.EXTRA_SYSTEM_HINT or "").strip()
    if extra:
        system_parts.append(extra)

    if system_parts:
        return [{"role": "system", "content": "\n\n".join(system_parts)}] + rest
    return rest


def _split_system(messages: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], list[dict[str, Any]]]:
    """Отделяем head=system-сообщения от тела истории."""
    head: list[dict[str, Any]] = []
    body: list[dict[str, Any]] = []
    for m in messages:
        if not isinstance(m, dict):
            continue
        if m.get("role") == "system" and not body:
            head.append(m)
        else:
            body.append(m)
    return head, body


def _strip_tool_history(messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Убираем tool/function-сообщения и assistant-вызовы инструментов."""
    out: list[dict[str, Any]] = []
    for m in messages:
        if not isinstance(m, dict):
            continue
        role = m.get("role")
        if role in ("tool", "function"):
            continue
        if role == "assistant" and (m.get("tool_calls") or m.get("function_call")):
            continue
        out.append(m)
    return out


_FAILED_TOOL_MARKERS = (
    '"status":"error"',
    '"status": "error"',
    '"error":',
    'Missing required parameter',
    '<empty-string>',
)


def _is_failed_tool_content(content: Any) -> bool:
    if not isinstance(content, str):
        return False
    return any(marker in content for marker in _FAILED_TOOL_MARKERS)


def _drop_failed_tool_results(messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """
    Удаляем неуспешные tool/function-ответы и породившие их assistant-вызовы.
    Чистые успешные обмены остаются, чтобы модель видела пример вызова инструмента.
    """
    if not isinstance(messages, list):
        return messages

    indices_to_drop: set[int] = set()
    for i, m in enumerate(messages):
        if not isinstance(m, dict):
            continue
        role = m.get("role")
        if role not in ("tool", "function"):
            continue
        if not _is_failed_tool_content(m.get("content")):
            continue
        indices_to_drop.add(i)
        for j in range(i - 1, -1, -1):
            prev = messages[j]
            if not isinstance(prev, dict):
                continue
            if prev.get("role") == "assistant" and (prev.get("tool_calls") or prev.get("function_call")):
                indices_to_drop.add(j)
            break

    if not indices_to_drop:
        return messages
    return [m for i, m in enumerate(messages) if i not in indices_to_drop]


def _trim_history(
    messages: list[dict[str, Any]],
    limit: int,
    *,
    preserve_message: dict[str, Any] | None = None,
) -> list[dict[str, Any]]:
    """Сохраняем system, закреплённый запрос и свежий хвост в пределах limit."""
    if not limit or limit <= 0:
        return messages
    head, body = _split_system(messages)
    if len(body) <= limit:
        return messages
    if preserve_message is not None:
        preserved_index = next(
            (i for i in range(len(body) - 1, -1, -1) if body[i] == preserve_message),
            None,
        )
        if preserved_index is not None and preserved_index < len(body) - limit:
            tail = body[-(limit - 1):] if limit > 1 else []
            return head + [body[preserved_index]] + tail
    return head + body[-limit:]


def _merge_consecutive_roles(messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """
    Склеиваем подряд идущие user/user или assistant/assistant без tool-вызовов.
    GigaChat требует строгого чередования и иначе валит 400 "invalid JSON syntax".
    """
    out: list[dict[str, Any]] = []
    for raw in messages:
        if not isinstance(raw, dict):
            continue
        msg = dict(raw)

        if not out:
            out.append(msg)
            continue

        prev = out[-1]
        prev_role = prev.get("role")
        cur_role = msg.get("role")

        merge_safe = (
            prev_role == cur_role
            and cur_role in ("user", "assistant")
            and not prev.get("tool_calls") and not prev.get("function_call")
            and not msg.get("tool_calls") and not msg.get("function_call")
        )

        if merge_safe:
            prev_content = prev.get("content") or ""
            cur_content = msg.get("content") or ""
            joined = (prev_content + "\n\n" + cur_content).strip() if prev_content or cur_content else ""
            prev["content"] = joined
        else:
            out.append(msg)

    return out


_INLINE_HINT = (
    "The tool above already finished successfully. "
    "Treat its output as ground truth, do NOT call the same tool again. "
    "Continue answering the user's original request."
)

# Hint для thinking-моделей: явный запрет копировать формат истории.
# Без него DeepSeek/Qwen видят `(prev assistant turn used tool "X" with arguments: ...)`
# в истории и начинают это сами эмитить как «вот так я зову инструмент».
_INLINE_HINT_THINKING = (
    "The tool finished successfully — treat its output as ground truth and do "
    "NOT call the same tool again. The block above is REFERENCE DATA describing "
    "what already happened; it is NOT the format you should use for new tool "
    "calls. When you need to call a tool now, follow ONLY the exact format "
    "specified in the system instructions at the top of this conversation. "
    "The `<<<TOOL HISTORY>>>` / `<<<END TOOL HISTORY>>>` and `<<<TOOL RESULT>>>` / "
    "`<<<END TOOL RESULT>>>` markers — along with EVERYTHING between them — "
    "are INTERNAL context for you only. NEVER quote, paraphrase, copy, or even "
    "mention these markers, their contents, tool names, or arguments in your "
    "reply to the user. The user must NEVER see these blocks or any reference "
    "to them. They are not part of your answer — treat them as silent memory."
)


def _inline_tool_history(
    messages: list[dict[str, Any]], *, model: Any = None
) -> list[dict[str, Any]]:
    """
    Сворачиваем последовательность assistant{tool_calls}+tool в одно
    ассистентское сообщение с понятным текстовым описанием:

        user: <запрос>
        assistant{tool_calls=[X], content=Y}
        tool{tool_call_id=X.id, content=R}
            -> assistant{content="Y\\n[tool: X(args)] -> R\\n<подсказка>"}

    Если за tool-обменом идёт ещё user — он сохраняется как обычный шаг диалога.
    Если истории заканчивается на tool — добавляем явный hint, чтобы модель
    не зацикливалась и не повторяла свой же вызов (GigaChat IFT иначе уходит
    в loop, потому что не видит «настоящего» tool roundtrip).

    Зачем вообще: GigaChat IFT не принимает legacy `function_call`/`function`
    в request messages — валит 400 "invalid JSON syntax". При этом `functions`
    для вызова инструментов он поддерживает. Сворачивание сохраняет контекст
    для модели в безопасном чисто текстовом формате.

    Для thinking-моделей (DeepSeek/Qwen3/GLM/MiniMax) используется
    отдельный, нарочно «не-копируемый» формат с маркерами `<<<...>>>`
    и явным disclaimer'ом «не используй этот формат для новых вызовов»
    — иначе модель видит `(prev assistant turn used tool "X" ...)` в
    истории и начинает повторять его как способ звать инструменты.
    """
    if not isinstance(messages, list):
        return messages

    is_thinking = _is_thinking_model(model)

    # Сначала собираем маппинг tool_call_id -> name, чтобы корректно подписывать
    # результаты, у которых OpenClaw не шлёт `name` отдельно.
    id_to_name: dict[str, str] = {}
    for msg in messages:
        if not isinstance(msg, dict):
            continue
        for tc in msg.get("tool_calls") or []:
            if not isinstance(tc, dict):
                continue
            tc_id = tc.get("id")
            fn = tc.get("function") or {}
            name = fn.get("name") if isinstance(fn, dict) else None
            if tc_id and name:
                id_to_name[tc_id] = name

    def _format_call_legacy(name: str, arguments: Any) -> str:
        """Старый passive-voice формат для не-thinking моделей (Qwen3 и legacy).

        Намеренно используем нарративный «passive voice»-формат, а не
        короткий шаблон-команду вроде `[tool call: NAME] {...}`. Иначе
        Qwen3.6-35b учится на этом формате прямо в контексте и
        Qwen3.6-35b учится на этом формате прямо в контексте и
        начинает писать его в delta.content вместо настоящих tool_calls,
        из-за чего пользователь видит в чате сырой JSON.
        """
        if not isinstance(arguments, str):
            arguments = json.dumps(arguments, ensure_ascii=False)
        return (
            f'(prev assistant turn used tool "{name}" with arguments: '
            f"{arguments})"
        )

    def _format_call_thinking(name: str, arguments: Any) -> str:
        """Нарративный markdown-формат для thinking-моделей.

        Оборачиваем аргументы в fenced code-block — модель видит их как
        ДАННЫЕ, а не как шаблон вызова. Маркер `<<<TOOL HISTORY>>>`
        не используется ни в одном tool-call формате, так что модель
        физически не сможет его перепутать с инструкцией.
        """
        if not isinstance(arguments, str):
            arguments = json.dumps(arguments, ensure_ascii=False)
        return (
            f"<<<TOOL HISTORY (reference only — DO NOT copy this format)>>>\n"
            f"At an earlier turn the `{name}` tool was invoked.\n"
            f"Arguments used (data only):\n"
            f"```json\n{arguments}\n```\n"
            f"<<<END TOOL HISTORY>>>"
        )

    def _format_result(name: str, content: str) -> str:
        if is_thinking:
            return (
                f"<<<TOOL RESULT (reference only — DO NOT copy this format)>>>\n"
                f"The `{name}` tool returned:\n"
                f"```\n{content}\n```\n"
                f"<<<END TOOL RESULT>>>\n\n"
                + _INLINE_HINT_THINKING
            )
        return (
            f'(tool "{name}" returned the following result:)\n{content}'.rstrip()
            + "\n\n"
            + _INLINE_HINT
        )

    _format_call = _format_call_thinking if is_thinking else _format_call_legacy

    out: list[dict[str, Any]] = []
    for raw in messages:
        if not isinstance(raw, dict):
            continue
        msg = dict(raw)
        role = msg.get("role")

        if role in ("tool", "function"):
            name = msg.get("name") or id_to_name.get(msg.get("tool_call_id") or "", "tool")
            content = _stringify_content(msg.get("content"))
            out.append({"role": "user", "content": _format_result(name, content)})
            continue

        if role == "assistant" and (msg.get("tool_calls") or msg.get("function_call")):
            existing = _stringify_content(msg.get("content"))

            call_blocks: list[str] = []
            fc = msg.get("function_call")
            if isinstance(fc, dict) and fc.get("name"):
                call_blocks.append(_format_call(fc["name"], fc.get("arguments", "")))

            for tc in msg.get("tool_calls") or []:
                if not isinstance(tc, dict):
                    continue
                fn = tc.get("function") or {}
                if not isinstance(fn, dict) or not fn.get("name"):
                    continue
                call_blocks.append(_format_call(fn["name"], fn.get("arguments", "")))

            if is_thinking:
                # У thinking-моделей tool-history-блок ОБЯЗАТЕЛЬНО уходит в
                # роль `user` — иначе модель видит его в собственном
                # `assistant`-turn'е и копирует формат в свои новые ответы
                # (Qwen3.5/DeepSeek так делают, см. инцидент 18.05.2026).
                if existing.strip():
                    out.append({"role": "assistant", "content": existing})
                if call_blocks:
                    out.append({
                        "role": "user",
                        "content": "\n\n".join(call_blocks),
                    })
            else:
                # Для не-thinking моделей оставляем старое поведение —
                # они не «учатся» на формате истории.
                parts: list[str] = []
                if existing:
                    parts.append(existing)
                parts.extend(call_blocks)
                text = "\n".join(p for p in parts if p) or "[tool call]"
                out.append({"role": "assistant", "content": text})
            continue

        msg["content"] = _stringify_content(msg.get("content"))
        out.append(msg)

    return out


def _to_legacy_messages(messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """
    Перекладываем OpenAI-роли в legacy GigaChat:
        role=tool, tool_call_id=X       -> role=function, name=<имя из соответствующего tool_call>
        assistant.tool_calls=[t1, ...]  -> assistant.function_call={name, arguments}
                                           (берём первый — у GigaChat нет parallel tool calls)
        content всегда строка.
    """
    if not isinstance(messages, list):
        return messages

    # Сначала: tool_call_id -> function_name (по предыдущим assistant.tool_calls).
    id_to_name: dict[str, str] = {}
    for msg in messages:
        if not isinstance(msg, dict):
            continue
        for tc in msg.get("tool_calls") or []:
            if isinstance(tc, dict):
                tc_id = tc.get("id")
                fn = tc.get("function") or {}
                name = fn.get("name") if isinstance(fn, dict) else None
                if tc_id and name:
                    id_to_name[tc_id] = name

    out: list[dict[str, Any]] = []
    for raw in messages:
        if not isinstance(raw, dict):
            continue
        msg = dict(raw)
        msg["content"] = _stringify_content(msg.get("content"))
        role = msg.get("role")

        if role == "tool":
            tool_call_id = msg.pop("tool_call_id", None)
            name = msg.pop("name", None) or id_to_name.get(tool_call_id or "", "tool")
            out.append({"role": "function", "name": name, "content": msg.get("content", "")})
            continue

        if role == "assistant" and msg.get("tool_calls"):
            tool_calls = msg.pop("tool_calls", []) or []
            first = tool_calls[0] if tool_calls else None
            if isinstance(first, dict):
                fn = first.get("function") or {}
                if isinstance(fn, dict) and fn.get("name"):
                    arguments = fn.get("arguments", "")
                    if not isinstance(arguments, str):
                        arguments = json.dumps(arguments, ensure_ascii=False)
                    msg["function_call"] = {"name": fn["name"], "arguments": arguments}
            # legacy-spec: при assistant.function_call поле content
            # должно отсутствовать (GigaChat иначе кричит "invalid JSON syntax").
            if "function_call" in msg and not msg.get("content"):
                msg.pop("content", None)
            out.append(msg)
            continue

        out.append(msg)

    return out


def _coerce_tool_choice(value: Any) -> Any:
    """
    GigaChat понимает tool_choice="auto"/"none" и объект {"type":"function","function":{"name":...}}.
    OpenAI'шный "required" нативного аналога не имеет — по умолчанию приводим к "auto",
    но это можно отключить через STRICT_TOOL_CHOICE=true.
    """
    if value == "required" and not Settings.STRICT_TOOL_CHOICE:
        return "auto"
    return value


def _flatten_combinator(node: dict[str, Any]) -> dict[str, Any]:
    """
    `anyOf`/`oneOf` из const-вариантов одного типа -> простой `enum` + `type`.
    Если ветви разнотипные/со схемами — просто берём первую, чтобы сохранить
    хоть какой-то валидный type (GigaChat комбинаторы не понимает).
    """
    for key in ("anyOf", "oneOf"):
        branches = node.get(key)
        if not isinstance(branches, list) or not branches:
            continue

        consts: list[Any] = []
        consts_type: Optional[str] = None
        ok = True
        for br in branches:
            if not isinstance(br, dict):
                ok = False
                break
            if "const" not in br:
                ok = False
                break
            t = br.get("type")
            if consts_type is None:
                consts_type = t if isinstance(t, str) else None
            elif isinstance(t, str) and t != consts_type:
                ok = False
                break
            consts.append(br["const"])

        if ok and consts:
            node.pop(key, None)
            node.pop("allOf", None)
            node.setdefault("type", consts_type or "string")
            node["enum"] = consts
        else:
            first = next((b for b in branches if isinstance(b, dict)), {})
            node.pop(key, None)
            for k, v in first.items():
                node.setdefault(k, v)

    if "const" in node and "enum" not in node:
        const_value = node.pop("const")
        node["enum"] = [const_value]
        if "type" not in node and isinstance(const_value, str):
            node["type"] = "string"

    return node


def _sanitize_json_schema(schema: Any) -> Any:
    """
    Нормализует JSON Schema под требования GigaChat:
        * у любого `type: "object"` обязан быть `properties` (хотя бы пустой);
        * `anyOf`/`oneOf`/`const` сводим к простым `type` + `enum` (GigaChat
          расширенные комбинаторы валидатор отвергает с 422);
        * убираем поля, на которые GigaChat-валидатор ругается;
        * чиним ситуации, когда `parameters` отсутствует или None.
    Безопасно для OpenAI-семантики: смысл схемы (допустимые значения) сохраняется.
    """
    if isinstance(schema, list):
        return [_sanitize_json_schema(item) for item in schema]

    if not isinstance(schema, dict):
        return schema

    out: dict[str, Any] = {}
    drop_keys = {"$schema", "$id", "$ref", "patternProperties", "$comment"}
    for key, value in schema.items():
        if key in drop_keys:
            continue
        out[key] = _sanitize_json_schema(value)

    out = _flatten_combinator(out)

    if out.get("type") == "object":
        props = out.get("properties")
        if not isinstance(props, dict):
            out["properties"] = {}

    add_props = out.get("additionalProperties")
    if isinstance(add_props, dict):
        out["additionalProperties"] = _sanitize_json_schema(add_props)

    return out


def _sanitize_function_def(fn: Any) -> Any:
    """Чистит описание функции и её параметры (parameters)."""
    if not isinstance(fn, dict):
        return fn
    fn = dict(fn)
    params = fn.get("parameters")
    if not isinstance(params, dict):
        params = {"type": "object", "properties": {}}
    fn["parameters"] = _sanitize_json_schema(params)
    return fn


def _sanitize_tools(tools: Any) -> Any:
    if not isinstance(tools, list):
        return tools
    cleaned = []
    for t in tools:
        if not isinstance(t, dict):
            continue
        t = dict(t)
        if Settings.STRIP_TOOL_STRICT:
            t.pop("strict", None)
        if t.get("type") == "function":
            fn = _sanitize_function_def(t.get("function"))
            if isinstance(fn, dict) and Settings.STRIP_TOOL_STRICT:
                fn.pop("strict", None)
            t["function"] = fn
        cleaned.append(t)
    return cleaned


def _to_legacy_functions(payload: dict[str, Any]) -> dict[str, Any]:
    """tools[] -> functions[], tool_choice -> function_call (старый OpenAI/GigaChat формат)."""
    tools = payload.pop("tools", None)
    if isinstance(tools, list):
        functions = []
        for t in tools:
            if isinstance(t, dict) and t.get("type") == "function":
                fn = t.get("function") or {}
                if isinstance(fn, dict):
                    functions.append(_sanitize_function_def(fn))
        if functions:
            payload["functions"] = functions

    choice = payload.pop("tool_choice", None)
    if choice is not None:
        if choice in ("auto", "none"):
            payload["function_call"] = choice
        elif isinstance(choice, dict) and choice.get("type") == "function":
            fn = choice.get("function") or {}
            name = fn.get("name") if isinstance(fn, dict) else None
            if name:
                payload["function_call"] = {"name": name}
    return payload


_FALLBACK_MODEL = "Qwen3.5-397b"


def _coerce_model(requested: Any) -> str:
    """Подменяем чужие model id на DEFAULT_MODEL, если они не из набора GigaChat."""
    if not isinstance(requested, str) or not requested.strip():
        return Settings.DEFAULT_MODEL

    requested = requested.strip()
    if not Settings.FORCE_MODEL:
        return requested

    if requested in Settings.known_models():
        return requested

    return Settings.DEFAULT_MODEL


def _model_unavailable(status: int, err_text: str) -> bool:
    """Апстрим не знает модель: 404 или текст model_not_found."""
    if status == 404:
        return True
    low = err_text.lower()
    return "model_not_found" in low or "does not exist" in low or "no such model" in low


def _with_fallback_model(payload: dict[str, Any]) -> dict[str, Any] | None:
    """Qwen3.6 не ответила — тот же запрос на Qwen3.5. Второй раз не подменяем."""
    if payload.get("model") != "Qwen3.6-35b":
        return None
    retry = dict(payload)
    retry["model"] = _FALLBACK_MODEL
    return retry


def transform_request(body: dict[str, Any]) -> dict[str, Any]:
    out = {k: v for k, v in body.items() if k in _ALLOWED_REQUEST_FIELDS}

    # Always disable GigaChat profanity/censorship filter.
    out["profanity_check"] = False

    requested_model = body.get("model")
    out["model"] = _coerce_model(requested_model)
    if requested_model and out["model"] != requested_model:
        log.info("Model coerced: %s -> %s", requested_model, out["model"])

    if "messages" in out:
        out["messages"] = _normalize_messages(out["messages"])

    if "tool_choice" in out:
        out["tool_choice"] = _coerce_tool_choice(out["tool_choice"])

    if "tools" in out:
        out["tools"] = _sanitize_tools(out["tools"])

    if "functions" in out and isinstance(out["functions"], list):
        out["functions"] = [_sanitize_function_def(f) for f in out["functions"]]

    # LEGACY conversion (`tools` -> `functions`) нужна для GigaChat, но
    # ломает thinking-модели (Qwen3, DeepSeek-R1) — они «не видят» инструменты
    # в legacy-схеме и просто пишут «вызову X» текстом, ничего не делая.
    # См. OpenClaw issues #1866, #8923, #41328.
    is_thinking = _is_thinking_model(out.get("model"))
    if Settings.LEGACY_FUNCTIONS and not (
        is_thinking and Settings.THINKING_USE_NEW_TOOLS
    ):
        out = _to_legacy_functions(out)

    _apply_min_max_tokens(out)

    if "messages" in out and isinstance(out["messages"], list):
        msgs = out["messages"]
        notes_user_message = None
        if _openclaw_context_from_messages(msgs).get("agent") == "fi-sales":
            # После инлайна tool-обмены тоже получают role=user. Закрепляем
            # исходный запрос заранее: в нём история заметки и текущий черновик.
            notes_user_message = next(
                (dict(m) for m in reversed(msgs) if m.get("role") == "user"),
                None,
            )

        # Утёкший <tool_call> в assistant.content без tool result отравляет
        # следующие ходы (модель копирует формат и снова не вызывает exec).
        msgs = _drop_leaked_assistant_tool_calls(msgs)

        # Сначала чистим заведомо мёртвые tool-обмены (status:error и t.п.),
        # пока ещё видны исходные роли tool/function.
        if Settings.STRIP_TOOL_HISTORY:
            msgs = _strip_tool_history(msgs)
        elif Settings.DROP_FAILED_TOOL_RESULTS:
            msgs = _drop_failed_tool_results(msgs)

        # Дальше — либо «инлайним» tool-обмены в обычный текст, либо
        # переводим их в legacy-формат GigaChat. Инлайн надёжнее, потому
        # что IFT-сборка часто валит 400 на legacy-сообщениях в истории.
        # Для thinking-моделей с новым `tools` форматом — оставляем нативный
        # обмен (assistant.tool_calls + role:tool), модель так лучше понимает
        # что инструмент уже вызывался.
        use_native_tool_history = (
            is_thinking
            and Settings.THINKING_USE_NEW_TOOLS
            and Settings.THINKING_NATIVE_TOOL_HISTORY
        )
        if use_native_tool_history:
            pass  # только если upstream реально понимает role:tool в history
        elif Settings.INLINE_TOOL_HISTORY:
            msgs = _inline_tool_history(msgs, model=out.get("model"))
        elif Settings.LEGACY_FUNCTIONS:
            msgs = _to_legacy_messages(msgs)

        if Settings.MAX_HISTORY_MESSAGES:
            msgs = _trim_history(
                msgs, Settings.MAX_HISTORY_MESSAGES,
                preserve_message=notes_user_message,
            )
        if Settings.MERGE_CONSECUTIVE_ROLES:
            msgs = _merge_consecutive_roles(msgs)

        # Для thinking-моделей: дочищаем `<think>` блоки, оставшиеся в
        # ассистентских сообщениях из прошлых ходов.
        if is_thinking and Settings.STRIP_THINK_FROM_HISTORY:
            msgs = _strip_think_from_messages(msgs)

        # Для thinking-моделей собираем дополнения к system-промпту в строгом
        # порядке:
        #   1) Hermes-каталог тулзов (`# Tools` + `<tools>...</tools>` +
        #      описание формата `<tool_call>`). КРИТИЧНО, потому что IFT
        #      не пробрасывает `tools` для не-GigaChat моделей и без
        #      явного списка Qwen «не видит» инструменты.
        #   2) Поведенческие правила (EXTRA_THINKING_HINT), которые
        #      ссылаются на «<tools> list above» — поэтому идут ПОСЛЕ.
        catalog_injected = False
        catalog_tool_names: list[str] = []
        if is_thinking:
            if Settings.INJECT_TOOL_CATALOG:
                tools_for_catalog = out.get("tools") or _functions_as_tools(
                    out.get("functions")
                )
                if tools_for_catalog:
                    catalog = _render_tool_catalog_for_model(
                        out.get("model"), tools_for_catalog
                    )
                    if catalog:
                        msgs = _inject_extra_system_hint(msgs, catalog)
                        catalog_injected = True
                        for t in tools_for_catalog:
                            if isinstance(t, dict) and isinstance(
                                t.get("function"), dict
                            ):
                                name = t["function"].get("name")
                                if name:
                                    catalog_tool_names.append(str(name))
            if Settings.EXTRA_THINKING_HINT:
                msgs = _inject_extra_system_hint(
                    msgs, Settings.EXTRA_THINKING_HINT
                )

        out["messages"] = msgs

        # Диагностический дамп для thinking-моделей: фиксируем, что именно
        # ушло наверх в system и какие тулзы модели «показали».
        if is_thinking:
            system_full = ""
            for m in msgs:
                if isinstance(m, dict) and m.get("role") == "system" and isinstance(
                    m.get("content"), str
                ):
                    system_full = m["content"]
                    break
            _dump_to_file(
                "THINKING REQUEST DEBUG",
                {
                    "model": out.get("model"),
                    "is_thinking": True,
                    "tools_in_payload": isinstance(out.get("tools"), list)
                    and len(out.get("tools") or []),
                    "functions_in_payload": isinstance(out.get("functions"), list)
                    and len(out.get("functions") or []),
                    "catalog_injected": catalog_injected,
                    "catalog_tool_names": catalog_tool_names,
                    "system_chars": len(system_full),
                    "system_full": system_full,
                },
            )

    return out


def _functions_as_tools(functions: Any) -> list[dict[str, Any]]:
    """Конвертирует legacy `functions[]` обратно в `tools[]` для рендера."""
    if not isinstance(functions, list):
        return []
    tools: list[dict[str, Any]] = []
    for fn in functions:
        if isinstance(fn, dict):
            tools.append({"type": "function", "function": fn})
    return tools


def _tools_to_compact(tools: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Снимает обёртку `{"type":"function","function":{...}}` и оставляет
    голый `{"name", "description", "parameters"}` — формат, на котором
    обучены все целевые модели (Qwen3, GLM, MiniMax, DeepSeek)."""
    out: list[dict[str, Any]] = []
    for t in tools or []:
        if not isinstance(t, dict):
            continue
        if t.get("type") != "function":
            continue
        fn = t.get("function")
        if not isinstance(fn, dict) or not fn.get("name"):
            continue
        out.append({
            "name": fn.get("name"),
            "description": fn.get("description", ""),
            "parameters": fn.get("parameters") or {"type": "object", "properties": {}},
        })
    return out


# ---------------------------------------------------------------------------
# Per-model рендер каталога инструментов в системном промпте.
# Каждая семья моделей обучена на СВОЁМ формате tool_call. Если дать DeepSeek
# инструкцию Hermes — она будет «спорить» с ней и выдавать смесь форматов.
# Поэтому подставляем модели её родной шаблон один-в-один.
# ---------------------------------------------------------------------------


def _render_hermes_catalog(tools: list[dict[str, Any]]) -> str:
    """Каталог в формате Qwen3 / Qwen2.5 (Hermes)."""
    compact = _tools_to_compact(tools)
    if not compact:
        return ""
    lines = [json.dumps(t, ensure_ascii=False) for t in compact]
    return (
        "# Tools\n\n"
        "You may call one or more functions to assist with the user query.\n\n"
        "You are provided with function signatures within "
        "<tools></tools> XML tags:\n"
        "<tools>\n"
        + "\n".join(lines)
        + "\n</tools>\n\n"
        "For each function call, return a json object with function name "
        "and arguments within <tool_call></tool_call> XML tags:\n"
        "<tool_call>\n"
        '{"name": <function-name>, "arguments": <args-json-object>}\n'
        "</tool_call>"
    )


def _render_glm_catalog(tools: list[dict[str, Any]]) -> str:
    """Каталог в формате ChatGLM-4.5/4.6/5.x.

    Точная структура взята из официального chat_template.jinja:
    https://huggingface.co/zai-org/GLM-4.6/blob/main/chat_template.jinja
    """
    compact = _tools_to_compact(tools)
    if not compact:
        return ""
    lines = [json.dumps(t, ensure_ascii=False) for t in compact]
    return (
        "# Tools\n\n"
        "You may call one or more functions to assist with the user query.\n\n"
        "You are provided with function signatures within <tools></tools> XML tags:\n"
        "<tools>\n"
        + "\n".join(lines)
        + "\n</tools>\n\n"
        "For each function call, output the function name and arguments "
        "within the following XML format:\n"
        "<tool_call>{function-name}\n"
        "<arg_key>{arg-key-1}</arg_key>\n"
        "<arg_value>{arg-value-1}</arg_value>\n"
        "<arg_key>{arg-key-2}</arg_key>\n"
        "<arg_value>{arg-value-2}</arg_value>\n"
        "...\n"
        "</tool_call>"
    )


def _render_minimax_catalog(tools: list[dict[str, Any]]) -> str:
    """Каталог в формате MiniMax-M2 (XML с <invoke>/<parameter>).

    Точная структура взята из официального tool_calling_guide.md:
    https://huggingface.co/MiniMaxAI/MiniMax-M2/blob/main/docs/tool_calling_guide.md
    """
    compact = _tools_to_compact(tools)
    if not compact:
        return ""
    lines = [
        f"<tool>{json.dumps(t, ensure_ascii=False)}</tool>"
        for t in compact
    ]
    return (
        "# Tools\n"
        "You may call one or more tools to assist with the user query.\n"
        "Here are the tools available in JSONSchema format:\n\n"
        "<tools>\n"
        + "\n".join(lines)
        + "\n</tools>\n\n"
        "When making tool calls, use XML format to invoke tools and pass parameters:\n\n"
        "<minimax:tool_call>\n"
        '<invoke name="tool-name-1">\n'
        '<parameter name="param-key-1">param-value-1</parameter>\n'
        '<parameter name="param-key-2">param-value-2</parameter>\n'
        "</invoke>\n"
        "</minimax:tool_call>"
    )


def _render_deepseek_catalog(tools: list[dict[str, Any]]) -> str:
    """Каталог для DeepSeek-V3.x.

    DeepSeek нативно ждёт спец-юникод-токены (`<｜tool▁call▁begin｜>...`),
    но IFT их часто фильтрует. Чтобы получить стабильный результат через
    OpenAI-совместимый канал, просим модель использовать Hermes-стиль —
    он короче, без спецтокенов и хорошо понимается этой архитектурой.
    """
    compact = _tools_to_compact(tools)
    if not compact:
        return ""
    lines = [json.dumps(t, ensure_ascii=False) for t in compact]
    return (
        "# Tools\n\n"
        "You have access to the following tools. Whenever you decide to call "
        "one, output the tool call ALWAYS using the format below — do NOT "
        "use any other format, do NOT use special tokens.\n\n"
        "<tools>\n"
        + "\n".join(lines)
        + "\n</tools>\n\n"
        "Format for EACH tool call (one tool call per `<tool_call>` block, "
        "JSON object inside):\n"
        "<tool_call>\n"
        '{"name": "<function-name>", "arguments": {<args-as-json-object>}}\n'
        "</tool_call>\n\n"
        "Do not wrap arguments in XML tags. Do not use <invoke>, <parameter>, "
        "<arg_key>, or attribute-style tags. Use ONLY the JSON form above."
    )


def _render_tool_catalog_for_model(
    model: Any, tools: list[dict[str, Any]]
) -> str:
    """Диспетчер: возвращает каталог в формате, родном для модели.

    Поддерживаемые семьи (regex по имени модели):
      * GLM-* → ChatGLM XML с `<arg_key>/<arg_value>`
      * MiniMax-* → XML с `<invoke>/<parameter>`
      * DeepSeek-* → Hermes (родной формат блокируется через IFT)
      * Всё остальное (Qwen3, Qwen2.5, …) → Hermes
    """
    if not isinstance(model, str):
        return _render_hermes_catalog(tools)
    name = model.lower()
    if re.search(r"\bglm[-_]?\d", name) or "chatglm" in name:
        return _render_glm_catalog(tools)
    if "minimax" in name:
        return _render_minimax_catalog(tools)
    if "deepseek" in name:
        return _render_deepseek_catalog(tools)
    return _render_hermes_catalog(tools)


def _render_tool_catalog(tools: list[dict[str, Any]]) -> str:
    """Алиас для обратной совместимости — рендерит Hermes-формат (Qwen3).

    Новый код должен использовать `_render_tool_catalog_for_model`, который
    выбирает родной формат для конкретной семьи моделей. Этот шорткат
    оставлен только для тех мест, где модель неизвестна.
    """
    return _render_hermes_catalog(tools)


def _strip_think_from_messages(messages: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Вырезает `<think>...</think>` блоки из всех assistant.content."""
    out: list[dict[str, Any]] = []
    for msg in messages:
        if not isinstance(msg, dict):
            out.append(msg)
            continue
        if msg.get("role") == "assistant" and isinstance(msg.get("content"), str):
            cleaned = _strip_think_full(msg["content"]).strip()
            if cleaned or msg.get("tool_calls") or msg.get("function_call"):
                new = dict(msg)
                new["content"] = cleaned
                out.append(new)
            # Если после очистки assistant пустой и без tool_call — пропускаем
            # сообщение целиком, иначе оно превратится в пустую реплику.
            continue
        out.append(msg)
    return out


def _inject_extra_system_hint(
    messages: list[dict[str, Any]], hint: str
) -> list[dict[str, Any]]:
    """Дописывает hint к первому system-сообщению или вставляет новое."""
    if not hint:
        return messages
    out = [dict(m) if isinstance(m, dict) else m for m in messages]
    for msg in out:
        if isinstance(msg, dict) and msg.get("role") == "system":
            existing = msg.get("content") or ""
            if hint in existing:
                return out
            sep = "\n\n" if existing else ""
            msg["content"] = f"{existing}{sep}{hint}"
            return out
    out.insert(0, {"role": "system", "content": hint})
    return out


def _legacy_function_to_tool_calls(message: dict[str, Any]) -> dict[str, Any]:
    """Приводим устаревший function_call к новому tool_calls."""
    fn = message.get("function_call")
    if not fn or message.get("tool_calls"):
        return message

    arguments = fn.get("arguments", "")
    if not isinstance(arguments, str):
        arguments = json.dumps(arguments, ensure_ascii=False)

    message = dict(message)
    message["tool_calls"] = [
        {
            "id": f"call_{uuid.uuid4().hex[:24]}",
            "type": "function",
            "function": {
                "name": fn.get("name", ""),
                "arguments": arguments,
            },
        }
    ]
    message.pop("function_call", None)
    return message


_THINK_FULL_BLOCK_RE = re.compile(
    r"<\s*(think|thinking|reasoning|thought)\s*>.*?<\s*/\s*\1\s*>",
    re.IGNORECASE | re.DOTALL,
)


def _strip_think_full(text: str) -> str:
    """Вырезает все `<think>...</think>` блоки из готового текста."""
    if not text or "<" not in text:
        return text
    return _THINK_FULL_BLOCK_RE.sub("", text)


def _split_think_full(text: str) -> tuple[str, str]:
    """Разделяет текст на (видимый_ответ, reasoning).

    Reasoning склеивается из всех `<think>...</think>` (и `<reasoning>...`,
    `<thought>...`, `<thinking>...`) блоков по порядку появления, разделяясь
    переводами строк.
    """
    if not text or "<" not in text:
        return text, ""
    reasoning_parts: list[str] = []

    def _capture(match: re.Match[str]) -> str:
        inner = match.group(0)
        # Берём содержимое между открывающим и закрывающим тегом.
        body = re.sub(r"^<\s*\w+\s*>", "", inner, count=1, flags=re.IGNORECASE)
        body = re.sub(r"<\s*/\s*\w+\s*>$", "", body, count=1, flags=re.IGNORECASE)
        if body.strip():
            reasoning_parts.append(body.strip())
        return ""

    visible = _THINK_FULL_BLOCK_RE.sub(_capture, text)
    return visible, "\n\n".join(reasoning_parts)


def transform_response(payload: dict[str, Any]) -> dict[str, Any]:
    hide_think = Settings.HIDE_THINK_BLOCKS and _is_thinking_model(payload.get("model"))
    emit_reasoning = Settings.EMIT_REASONING_CONTENT
    choices = payload.get("choices")
    if isinstance(choices, list):
        for ch in choices:
            msg = ch.get("message")
            if isinstance(msg, dict):
                if hide_think and isinstance(msg.get("content"), str):
                    if emit_reasoning:
                        visible, reasoning = _split_think_full(msg["content"])
                        msg["content"] = visible.lstrip()
                        if reasoning:
                            existing = msg.get("reasoning_content")
                            msg["reasoning_content"] = (
                                f"{existing}\n\n{reasoning}".strip()
                                if isinstance(existing, str) and existing
                                else reasoning
                            )
                    else:
                        msg["content"] = _strip_think_full(msg["content"]).lstrip()
                ch["message"] = _legacy_function_to_tool_calls(msg)
    return payload


def transform_stream_chunk(chunk: dict[str, Any]) -> list[dict[str, Any]]:
    """
    Приводит upstream-чанк к строгому OpenAI streaming-формату:
      * legacy `delta.function_call` -> `delta.tool_calls`;
      * `finish_reason: "function_call"` -> `"tool_calls"`,
        если в delta присутствуют tool_calls;
      * проставляет `tool_calls[i].index` (OpenAI spec требует);
      * выкусывает GigaChat-специфику (`functions_state_id`, `additional_data`),
        чтобы клиент не спотыкался;
      * расщепляет «монолитный» чанк (delta+finish_reason одновременно)
        на два — это часто ломает OpenAI-совместимых клиентов.

    Возвращает список чанков (1 или 2), которые нужно отдать клиенту по порядку.
    """
    chunk.pop("additional_data", None)

    choices = chunk.get("choices")
    if not isinstance(choices, list) or not choices:
        return [chunk]

    needs_split = False
    for ch in choices:
        delta = ch.get("delta")
        if not isinstance(delta, dict):
            continue

        delta.pop("functions_state_id", None)

        if delta.get("function_call") and not delta.get("tool_calls"):
            ch["delta"] = _legacy_function_to_tool_calls(delta)
            delta = ch["delta"]

        tool_calls = delta.get("tool_calls")
        if isinstance(tool_calls, list) and tool_calls:
            for i, tc in enumerate(tool_calls):
                if isinstance(tc, dict) and "index" not in tc:
                    tc["index"] = i
            if ch.get("finish_reason") in ("function_call", "stop"):
                ch["finish_reason"] = "tool_calls"
            if ch.get("finish_reason") == "tool_calls":
                needs_split = True

    if not needs_split:
        return [chunk]

    base_common = {k: v for k, v in chunk.items() if k != "choices"}
    body_choices: list[dict[str, Any]] = []
    final_choices: list[dict[str, Any]] = []
    for ch in choices:
        if not isinstance(ch, dict):
            body_choices.append(ch)
            continue
        if ch.get("finish_reason") == "tool_calls" and isinstance(ch.get("delta"), dict) \
                and ch["delta"].get("tool_calls"):
            body = {k: v for k, v in ch.items() if k != "finish_reason"}
            body_choices.append(body)
            final_choices.append({
                "index": ch.get("index", 0),
                "delta": {},
                "finish_reason": "tool_calls",
            })
        else:
            body_choices.append(ch)

    if not final_choices:
        return [chunk]

    body_chunk = {**base_common, "choices": body_choices}
    final_chunk = {**base_common, "choices": final_choices}
    return [body_chunk, final_chunk]


# ---------------------------------------------------------------------------
# Поддержка thinking-моделей (Qwen3, DeepSeek-R1, …): подъём max_tokens и
# скрытие `<think>...</think>` от клиента.
# ---------------------------------------------------------------------------


_THINKING_MODEL_RE: Optional[re.Pattern[str]] = None


def _is_thinking_model(name: Any) -> bool:
    """Совпадает ли имя модели с шаблоном «думающей» модели."""
    global _THINKING_MODEL_RE
    if not isinstance(name, str) or not name:
        return False
    if _THINKING_MODEL_RE is None:
        try:
            _THINKING_MODEL_RE = re.compile(Settings.THINKING_MODEL_REGEX)
        except re.error:
            log.warning("Invalid THINKING_MODEL_REGEX, falling back to default")
            _THINKING_MODEL_RE = re.compile(
                r"(?i)(qwen[-_]?3|deepseek[-_ ]?r1|(?<!\w)r1(?!\w)|o[13](?:-|$)|thinking)"
            )
    return bool(_THINKING_MODEL_RE.search(name))


def _apply_min_max_tokens(payload: dict[str, Any]) -> None:
    """Поднимает `max_tokens` до пола для thinking-моделей."""
    floor = Settings.MIN_MAX_TOKENS_THINKING
    if floor <= 0:
        return
    if not _is_thinking_model(payload.get("model")):
        return

    current = payload.get("max_tokens")
    if isinstance(current, int) and current >= floor:
        return
    payload["max_tokens"] = floor


# Теги «думанья», которые умеют thinking-модели. Регистр игнорируем.
_THINK_OPEN_RE = re.compile(r"<\s*(think|thinking|reasoning|thought)\s*>", re.IGNORECASE)
_THINK_CLOSE_RE = re.compile(r"<\s*/\s*(think|thinking|reasoning|thought)\s*>", re.IGNORECASE)


class _ThinkBlockStripper:
    """
    Stateful-стриппер для стрима: вырезает содержимое `<think>...</think>`
    (а также `<reasoning>` / `<thought>`) из `delta.content`, чтобы клиент
    видел только финальный ответ модели.

    Поведение:
      * текст до открывающего тега — отдаём как есть;
      * текст внутри блока — глотаем (но накапливаем для отладки);
      * текст после закрывающего тега — снова отдаём;
      * если стрим закончился внутри незакрытого блока — отдаём fallback
        короткое уведомление, чтобы клиент не остался без ответа.

    Работает с дробными чанками (открывающий/закрывающий тег может приехать
    не одним куском, а разбитый по символам).
    """

    def __init__(self) -> None:
        self._inside = False
        # Хвост последнего chunk'а, в котором может «застревать» начало тега.
        self._tail = ""
        self._think_chars = 0
        # Видели ли мы хоть какое-то полезное содержимое снаружи блока.
        self._emitted_real_text = False
        # Текст, накопленный внутри `<think>` с момента последнего
        # `pop_reasoning()`. Используется для эмиссии `reasoning_content`
        # клиенту (см. `EMIT_REASONING_CONTENT`).
        self._reasoning_pending: list[str] = []

    @staticmethod
    def _looks_like_partial_tag(text: str) -> bool:
        """Может ли хвост текста начинать тег <think>/</think>/<thinking>/...?"""
        if not text:
            return False
        # Самый длинный возможный «недописанный» тег: `</reasoning` или `</thinking`.
        for cut in range(min(len(text), 11), 0, -1):
            tail = text[-cut:]
            if tail[0] != "<":
                continue
            tail_l = tail.lower()
            if (
                "<think".startswith(tail_l)
                or "</think".startswith(tail_l)
                or "<thinking".startswith(tail_l)
                or "</thinking".startswith(tail_l)
                or "<reasoning".startswith(tail_l)
                or "</reasoning".startswith(tail_l)
                or "<thought".startswith(tail_l)
                or "</thought".startswith(tail_l)
            ):
                return True
        return False

    def feed(self, text: str) -> str:
        """Принимает кусок `delta.content`, возвращает то, что можно отдать."""
        if not text:
            return ""

        buf = self._tail + text
        self._tail = ""
        out: list[str] = []
        i = 0
        n = len(buf)

        while i < n:
            if self._inside:
                m = _THINK_CLOSE_RE.search(buf, i)
                if not m:
                    if self._looks_like_partial_tag(buf[i:]):
                        # Хвост может оказаться частью закрывающего тега.
                        safe_end = max(i, n - 11)
                        if safe_end > i:
                            self._reasoning_pending.append(buf[i:safe_end])
                            self._think_chars += safe_end - i
                        self._tail = buf[safe_end:]
                    else:
                        self._reasoning_pending.append(buf[i:n])
                        self._think_chars += n - i
                    return "".join(out)
                if m.start() > i:
                    self._reasoning_pending.append(buf[i:m.start()])
                self._think_chars += m.start() - i
                i = m.end()
                self._inside = False
                continue

            m = _THINK_OPEN_RE.search(buf, i)
            if not m:
                # Обычный текст до конца буфера.
                if self._looks_like_partial_tag(buf[i:]):
                    safe_end = max(i, n - 11)
                    chunk = buf[i:safe_end]
                    if chunk:
                        out.append(chunk)
                        self._emitted_real_text = True
                    self._tail = buf[safe_end:]
                else:
                    out.append(buf[i:])
                    if buf[i:].strip():
                        self._emitted_real_text = True
                return "".join(out)

            chunk = buf[i:m.start()]
            if chunk:
                out.append(chunk)
                if chunk.strip():
                    self._emitted_real_text = True
            i = m.end()
            self._inside = True

        return "".join(out)

    def drain(self) -> str:
        """Финализация: остатки буфера + (опционально) fallback."""
        leftover: list[str] = []
        if self._tail:
            if not self._inside:
                leftover.append(self._tail)
                if self._tail.strip():
                    self._emitted_real_text = True
            else:
                # Хвост остался внутри незакрытого `<think>` — это reasoning,
                # а не настоящий ответ. Сохраним его как reasoning_content,
                # чтобы клиент мог хотя бы увидеть, о чём думала модель.
                self._reasoning_pending.append(self._tail)
                self._think_chars += len(self._tail)
            self._tail = ""
        # Если стрим оборвался внутри `<think>`, и наружу так и не вылетело
        # ничего полезного — оставим клиенту короткую заметку, чтобы он не
        # видел пустоту и не сорвался в повторный запрос.
        if self._inside and not self._emitted_real_text:
            leftover.append(
                "[модель оборвалась на reasoning, не дошла до ответа; "
                "увеличь MIN_MAX_TOKENS_THINKING или повтори запрос]"
            )
        self._inside = False
        return "".join(leftover)

    def pop_reasoning(self) -> str:
        """Отдаёт накопленный reasoning-текст и очищает буфер."""
        if not self._reasoning_pending:
            return ""
        text = "".join(self._reasoning_pending)
        self._reasoning_pending.clear()
        return text


# ---------------------------------------------------------------------------
# Защита от утечки inline-tool-history формата в delta.content
# ---------------------------------------------------------------------------
#
# Qwen3.6-35b часто учится прямо в контексте: видя в `messages[..].content`
# Qwen3.6-35b часто учится прямо в контексте: видя в `messages[..].content`
# наш текстовый маркер про предыдущий tool call, он начинает писать тот же
# маркер в `delta.content` вместо настоящего function_call. Тогда пользователь
# видит «сырой JSON в чате», а tool вообще не вызывается. Ниже rewriter,
# который ловит такие чанки и реассемблит их в нативный delta.tool_calls.

# Известные «утёкшие» префиксы. Старый `[tool call:` оставляем для совместимости
# с историями, накопленными до смены формата маркера.
_TOOL_LEAK_PREFIXES = (
    "[tool call:",
    '(prev assistant turn used tool "',
    "<tool_call>",
    "<minimax:tool_call>",
    # DeepSeek-V3.x native: <｜tool▁calls▁begin｜>...
    "\uff5ctool\u2581calls\u2581begin\uff5c>",
    "\uff5ctool\u2581call\u2581begin\uff5c>",
)

_TOOL_LEAK_PATTERNS = (
    re.compile(r"^\[tool call:\s*([A-Za-z_][\w\-]*)\]\s*", re.DOTALL),
    re.compile(
        r'^\(prev assistant turn used tool "([^"]+)" with arguments:\s*',
        re.DOTALL,
    ),
)

# Hermes/Qwen3 prompt-based tool-calling: <tool_call>{...}</tool_call>.
# Это наша основная схема, когда upstream не поддерживает OpenAI native
# function calling. Допускаем код-фенсы (```json) вокруг JSON и пробелы
# после открывающего тега.
_HERMES_TOOL_CALL_RE = re.compile(
    r"<\s*tool_call\s*>\s*(?:```(?:json|JSON)?\s*)?(\{.*?\})\s*(?:```\s*)?<\s*/\s*tool_call\s*>",
    re.DOTALL,
)

# Anthropic / DeepSeek XML-style: <tool_call><name>X</name><arguments>...</arguments></tool_call>.
# Внутри <arguments> может быть либо JSON-объект, либо плоские вложенные теги
# вида <command>cmd</command><description>desc</description>. Часть моделей
# на IFT (DeepSeek-V3.2, Qwen3.5) выбирают именно этот формат, игнорируя
# наш системный промпт с просьбой использовать JSON.
_TOOL_CALL_XML_BLOCK_RE = re.compile(
    r"<\s*tool_call\s*>(.*?)<\s*/\s*tool_call\s*>",
    re.DOTALL | re.IGNORECASE,
)
_TOOL_CALL_XML_NAME_RE = re.compile(
    r"<\s*name\s*>\s*(.*?)\s*<\s*/\s*name\s*>",
    re.DOTALL | re.IGNORECASE,
)
_TOOL_CALL_XML_ARGS_RE = re.compile(
    r"<\s*arguments\s*>\s*(.*?)\s*<\s*/\s*arguments\s*>",
    re.DOTALL | re.IGNORECASE,
)
_TOOL_CALL_XML_KV_RE = re.compile(
    r"<\s*([A-Za-z_][\w\-]*)\s*>(.*?)<\s*/\s*\1\s*>",
    re.DOTALL,
)

# Claude/Cline-style child-tag XML: <tool_call><NAME><k1>v1</k1><k2>v2</k2></NAME></tool_call>
# Имя инструмента — это сам первый child-тег внутри <tool_call>, аргументы —
# вложенные KV-теги. DeepSeek-V3.2 в OpenClaw тоже эмитит этот формат
# (учился на Claude/Roo/Cline-датасетах). Стандартный _parse_xml_calls для
# такого не подходит: там жёстко ищется <name>...</name> и
# <arguments>...</arguments>.
_TOOL_CALL_CHILD_OPEN_RE = re.compile(
    r"<\s*([A-Za-z_][\w\-]*)\s*>",
    re.DOTALL,
)

# DeepSeek attribute-style: <tool_call><bash command="..." description="..." /></tool_call>
# (имя инструмента — сам элемент, аргументы — XML-атрибуты, тег может быть
# самозакрытым `/>` или парным `></name>`). DeepSeek-V3.2 регулярно выбирает
# именно его. Чистым regex не парсим, потому что в значениях атрибутов
# встречаются `>` и `/` (например, `2>/dev/null`) — пользуемся stateful-сканером
# в `_ToolCallStreamRewriter._parse_attr_calls`.
_TOOL_CALL_NAME_HEAD_RE = re.compile(r"<\s*([A-Za-z_][\w\-]*)", re.DOTALL)
# Атрибут вида key="value", где value может содержать экранированные \" .
_TOOL_CALL_ATTR_KV_RE = re.compile(
    r'([A-Za-z_][\w\-]*)\s*=\s*"((?:\\.|[^"\\])*)"',
    re.DOTALL,
)

# ChatGLM-style: <tool_call>NAME<arg_key>K</arg_key><arg_value>V</arg_value>...</tool_call>.
# Имя инструмента — голый текст в начале блока, аргументы — последовательность
# пар <arg_key>/<arg_value>. GLM-4.5/GLM-5 обучались именно на таком формате.
_TOOL_CALL_GLM_NAME_RE = re.compile(
    r"^\s*([A-Za-z_][\w\-\.]*)\s*(?=<\s*arg_key\b)",
    re.DOTALL | re.IGNORECASE,
)
_TOOL_CALL_GLM_KV_RE = re.compile(
    r"<\s*arg_key\s*>\s*(.*?)\s*<\s*/\s*arg_key\s*>"
    r"\s*<\s*arg_value\s*>(.*?)<\s*/\s*arg_value\s*>",
    re.DOTALL | re.IGNORECASE,
)

# Qwen native (qwen_fncall): <tool_call><function=exec><parameter=command>...</parameter></function></tool_call>.
# Qwen3.5 часто пишет именно так, хотя в промпте просят Hermes-JSON.
# Без этого парсера блок содержит <tool_call, ни один разбор не сходится,
# и сейлз видит «Не удалось выполнить внутренний вызов инструмента».
_QWEN_FN_RE = re.compile(
    r"<\s*function\s*(?:=\s*|name\s*=\s*)[\"']?([A-Za-z_][\w\-\.]*)[\"']?\s*>"
    r"(.*?)<\s*/\s*function\s*>",
    re.DOTALL | re.IGNORECASE,
)
_QWEN_PARAM_RE = re.compile(
    r"<\s*parameter\s*(?:=\s*|name\s*=\s*)[\"']?([A-Za-z_][\w\-\.]*)[\"']?\s*>"
    r"(.*?)<\s*/\s*parameter\s*>",
    re.DOTALL | re.IGNORECASE,
)

# DeepSeek named-JSON: <tool_call><NAME>{json}</NAME></tool_call>.
# Имя инструмента — сам XML-тег, аргументы — JSON-объект внутри. Часть моделей
# IFT (DeepSeek-V3.2) иногда выбирает именно эту вариацию.
_TOOL_CALL_NAMED_BODY_RE = re.compile(
    r"<\s*([A-Za-z_][\w\-\.]*)\s*>(.+?)<\s*/\s*\1\s*>",
    re.DOTALL,
)

# MiniMax-M2 native: <minimax:tool_call><invoke name="X"><parameter name="K">V</parameter></invoke></minimax:tool_call>.
# Поддерживаем и вариант без префикса `minimax:` (некоторые сборки его опускают).
# См. https://huggingface.co/MiniMaxAI/MiniMax-M2/blob/main/docs/tool_calling_guide.md
_MINIMAX_BLOCK_RE = re.compile(
    r"<\s*(?:minimax:)?tool_call\s*>(.*?)<\s*/\s*(?:minimax:)?tool_call\s*>",
    re.DOTALL | re.IGNORECASE,
)
_MINIMAX_INVOKE_RE = re.compile(
    r'<\s*invoke\s+name\s*=\s*"([^"]+)"\s*>(.*?)<\s*/\s*invoke\s*>',
    re.DOTALL | re.IGNORECASE,
)
_MINIMAX_PARAM_RE = re.compile(
    r'<\s*parameter\s+name\s*=\s*"([^"]+)"\s*>(.*?)<\s*/\s*parameter\s*>',
    re.DOTALL | re.IGNORECASE,
)

# DeepSeek-V3.x native: <｜tool▁calls▁begin｜><｜tool▁call▁begin｜>NAME<｜tool▁sep｜>JSON<｜tool▁call▁end｜>...<｜tool▁calls▁end｜>.
# Используются спец-юникод-маркеры U+FF5C (｜) и U+2581 (▁). Маркеры
# исключительные, поэтому конфликтов с обычным текстом нет.
# См. https://huggingface.co/deepseek-ai/DeepSeek-V3.1/blob/main/assets/chat_template.jinja
_DS_TOOL_CALL_RE = re.compile(
    "\uff5ctool\u2581call\u2581begin\uff5c>"
    r"\s*(.+?)\s*"
    "\uff5ctool\u2581sep\uff5c>"
    r"\s*(.+?)\s*"
    "\uff5ctool\u2581call\u2581end\uff5c>",
    re.DOTALL,
)


def _extract_balanced_json_object(text: str) -> Optional[str]:
    """Возвращает первый сбалансированный JSON-object из текста (или None)."""
    start = text.find("{")
    if start < 0:
        return None
    depth = 0
    in_str = False
    esc = False
    for i in range(start, len(text)):
        ch = text[i]
        if esc:
            esc = False
            continue
        if ch == "\\":
            esc = True
            continue
        if ch == '"':
            in_str = not in_str
            continue
        if in_str:
            continue
        if ch == "{":
            depth += 1
        elif ch == "}":
            depth -= 1
            if depth == 0:
                return text[start : i + 1]
    return None


# Короткое сообщение пользователю, если <tool_call> не удалось распарсить/выполнить.
_TOOL_CALL_PARSE_FAIL_USER_MSG = (
    "Не удалось выполнить внутренний вызов инструмента. "
    "Пожалуйста, повторите вопрос — я попробую снова."
)

# Assistant-сообщение, состоящее только из «утёкшего» <tool_call> без tool result.
_LEAKED_TOOL_CALL_ONLY_RE = re.compile(
    r"^\s*<tool_call\s*>[\s\S]*?</tool_call\s*>\s*$",
    re.IGNORECASE,
)

_HERMES_TOOL_CALL_BLOCK_RE = re.compile(
    r"<\s*tool_call\s*>([\s\S]*?)<\s*/\s*tool_call\s*>",
    re.IGNORECASE,
)


def _strip_hermes_codeblock(inner: str) -> str:
    s = inner.strip()
    if s.startswith("```"):
        s = re.sub(r"^```(?:json|JSON)?\s*", "", s)
        s = re.sub(r"\s*```\s*$", "", s)
    return s.strip()


def _find_hermes_tool_call_json_bodies(text: str) -> list[str]:
    """Keep complete bodies and ignore XML-looking text inside JSON strings."""
    opening_re = re.compile(r"<\s*tool_call\s*>", re.IGNORECASE)
    closing_re = re.compile(r"<\s*/\s*tool_call\s*>", re.IGNORECASE)
    bodies: list[str] = []
    pos = 0
    while opening := opening_re.search(text, pos):
        start = opening.end()
        head = text[start:].lstrip()
        json_body = head.startswith(("{", "[", "```"))
        in_string = False
        escaped = False
        cursor = start
        while cursor < len(text):
            if not in_string:
                closing = closing_re.match(text, cursor)
                if closing:
                    bodies.append(_strip_hermes_codeblock(text[start:cursor]))
                    pos = closing.end()
                    break
            char = text[cursor]
            if json_body:
                if escaped:
                    escaped = False
                elif in_string and char == "\\":
                    escaped = True
                elif char == '"':
                    in_string = not in_string
            cursor += 1
        else:
            # Only fully valid JSON may recover a missing closing XML tag.
            bodies.append(_strip_hermes_codeblock(text[start:]))
            break
    return bodies


def _repair_tool_json(raw: str) -> str:
    """Чинит JSON, который модели пишут внутри <tool_call>: кривые кавычки, хвостовая запятая, сырой перевод строки в строке."""
    s = (
        raw.replace("\u201c", '"')
        .replace("\u201d", '"')
        .replace("\u2018", "'")
        .replace("\u2019", "'")
    )
    s = re.sub(r",(\s*[}\]])", r"\1", s)
    out: list[str] = []
    in_str = False
    esc = False
    for ch in s:
        if esc:
            out.append(ch)
            esc = False
            continue
        if ch == "\\":
            out.append(ch)
            esc = True
            continue
        if ch == '"':
            in_str = not in_str
            out.append(ch)
            continue
        if in_str and ch == "\n":
            out.append("\\n")
            continue
        if in_str and ch == "\r":
            continue
        out.append(ch)
    return "".join(out)


def _try_load_hermes_json(raw: str) -> Optional[dict[str, Any] | list[Any]]:
    """Parse the full payload; never invent a missing quote or command suffix."""
    s = raw.strip()
    candidates = [s, _repair_tool_json(s)]
    # Qwen may close arguments/env but omit the outer call's final brace.
    # Recover exactly that delimiter; json.loads must accept the entire result.
    for candidate in tuple(candidates):
        if candidate.startswith("{") and candidate.endswith("}"):
            candidates.append(candidate + "}")
    for candidate in dict.fromkeys(candidates):
        try:
            obj = json.loads(candidate)
        except json.JSONDecodeError:
            continue
        if isinstance(obj, (dict, list)):
            return obj
    return None


def _tool_arguments_json(arguments: Any) -> Optional[str]:
    """Tool arguments must be a JSON object, including when encoded as a string."""
    if isinstance(arguments, str):
        try:
            arguments = json.loads(arguments)
        except json.JSONDecodeError:
            return None
    if not isinstance(arguments, dict):
        return None
    try:
        return json.dumps(arguments, ensure_ascii=False, allow_nan=False)
    except (TypeError, ValueError):
        return None


def _hermes_obj_to_call(obj: dict[str, Any]) -> Optional[tuple[str, str]]:
    # OpenAI puts name/arguments inside "function"; Hermes uses flat fields.
    if isinstance(obj.get("function"), dict):
        if set(obj) - {"function", "type", "id", "index"}:
            return None
        obj = obj["function"]
    if set(obj) - {"name", "tool", "function", "arguments", "parameters", "args", "type", "id", "index"}:
        return None
    names = [obj[key] for key in ("name", "tool", "function") if key in obj]
    if not names or any(not isinstance(name, str) or not name.strip() for name in names):
        return None
    name = names[0].strip()
    if any(value.strip() != name for value in names):
        return None
    encoded = [
        _tool_arguments_json(obj[key])
        for key in ("arguments", "parameters", "args") if key in obj
    ]
    if not encoded:
        encoded = ["{}"]  # Tools with no parameters are valid.
    if any(arguments is None for arguments in encoded):
        return None
    canonical = {json.dumps(json.loads(arguments), sort_keys=True, ensure_ascii=False) for arguments in encoded}
    if len(canonical) != 1:
        return None
    return name, encoded[0]


def _parse_hermes_tool_call_batch(text: str) -> Optional[list[tuple[str, str]]]:
    """None means another syntax; [] means a malformed Hermes batch to reject."""
    bodies = _find_hermes_tool_call_json_bodies(text)
    if not any(body.startswith(("{", "[")) for body in bodies):
        return None
    results: list[tuple[str, str]] = []
    for raw in bodies:
        obj = _try_load_hermes_json(raw)
        if obj is None:
            return []
        if isinstance(obj, dict) and "tool_calls" in obj:
            if set(obj) - {"tool_calls"}:
                return []
            calls = obj["tool_calls"]
        else:
            calls = obj if isinstance(obj, list) else [obj]
        if not isinstance(calls, list) or not calls:
            return []
        for item in calls:
            if not isinstance(item, dict):
                return []
            call = _hermes_obj_to_call(item)
            if call is None:
                return []
            results.append(call)
    return results


def _parse_hermes_tool_calls(text: str) -> list[tuple[str, str]]:
    """Hermes/Qwen JSON envelopes -> an all-or-nothing list of tool calls."""
    return _parse_hermes_tool_call_batch(text) or []


def _is_leaked_tool_call_only_content(content: str) -> bool:
    if not isinstance(content, str) or not content.strip():
        return False
    return bool(_LEAKED_TOOL_CALL_ONLY_RE.match(content))


def _drop_leaked_assistant_tool_calls(
    messages: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Убирает из history assistant-текст с сырым <tool_call> (ломает следующие ходы)."""
    out: list[dict[str, Any]] = []
    for msg in messages:
        if not isinstance(msg, dict):
            out.append(msg)
            continue
        if (
            msg.get("role") == "assistant"
            and not msg.get("tool_calls")
            and not msg.get("function_call")
            and _is_leaked_tool_call_only_content(msg.get("content") or "")
        ):
            log.info(
                "history sanitizer: dropped leaked assistant <tool_call> message",
            )
            continue
        out.append(msg)
    return out


class _ToolCallStreamRewriter:
    """
    Stateful-перехватчик стрима. Решает две задачи:

    1. **Prompt-based tool calling** для апстримов, которые не поддерживают
       OpenAI native function-calling. Модель эмитит блоки
       ``<tool_call>{...}</tool_call>``; мы их парсим и переотдаём клиенту
       как нативные ``delta.tool_calls`` с ``finish_reason="tool_calls"``.

    2. **Защита от утечки** старого inline-tool-history маркера в
       ``delta.content`` (legacy GigaChat поведение).

    Логика:
      * Пока модель пишет обычный текст — пропускаем чанки как есть.
      * Как только в буфере появляется первый признак "леки" (``<tool_call>``
        или legacy маркер) — начинаем "придерживать" последующие чанки.
      * На ``finish_reason`` пытаемся разобрать накопленный буфер. Если
        нашли хотя бы один ``<tool_call>`` блок — выдаём массив tool_calls.
        Если ничего не распарсили — отдаём придержанные чанки как обычный
        текст (fallback).
    """

    def __init__(self) -> None:
        self._buffered: str = ""
        self._holding: bool = False
        self._held_chunks: list[dict[str, Any]] = []

    @staticmethod
    def _looks_leaky(text: str) -> bool:
        s = text.lstrip()
        if not s:
            return False
        for prefix in _TOOL_LEAK_PREFIXES:
            if s.startswith(prefix):
                return True
            if len(s) < len(prefix) and prefix.startswith(s):
                return True
        # Также реагируем на появление одного из known-маркеров где-нибудь
        # в середине буфера (модель часто пишет prelude вроде "Хорошо,
        # делаю:" перед самим вызовом).
        markers = (
            "<tool_call>",
            "<tool_call ",
            "<minimax:tool_call>",
            "\uff5ctool\u2581calls\u2581begin\uff5c>",
            "\uff5ctool\u2581call\u2581begin\uff5c>",
        )
        for marker in markers:
            if marker in s:
                return True
        return False

    @staticmethod
    def _parse_hermes_calls(text: str) -> list[tuple[str, str]]:
        """Возвращает список (name, arguments_json_str) из всех <tool_call>."""
        return _parse_hermes_tool_calls(text)

    @staticmethod
    def _parse_qwen_fn_calls(text: str) -> list[tuple[str, str]]:
        """Qwen native: `<function=exec><parameter=command>curl …</parameter></function>`.

        Внешний `<tool_call>` не обязателен: модель иногда его не закрывает.
        Значение параметра — строка как есть; если это JSON-массив или объект, разбираем.
        """
        results: list[tuple[str, str]] = []
        for fn in _QWEN_FN_RE.finditer(text):
            name = fn.group(1).strip()
            body = fn.group(2)
            if not name or name.lower() in {"name", "arguments", "tool_call"}:
                continue
            kv: dict[str, Any] = {}
            for pm in _QWEN_PARAM_RE.finditer(body):
                key = pm.group(1).strip()
                raw = pm.group(2).strip("\n").strip()
                if not key:
                    continue
                parsed: Any = raw
                if raw[:1] in "{[\"" or raw in {"true", "false", "null"}:
                    try:
                        parsed = json.loads(raw)
                    except json.JSONDecodeError:
                        parsed = raw
                kv[key] = parsed
            if not kv and "<" in body:
                continue
            results.append((name, json.dumps(kv, ensure_ascii=False)))
        return results

    @staticmethod
    def _parse_minimax_calls(text: str) -> list[tuple[str, str]]:
        """Парсит MiniMax-M2 native: `<minimax:tool_call><invoke name="X"><parameter name="K">V</parameter></invoke></minimax:tool_call>`.

        Значения `<parameter>` могут быть как plain-text (string), так и JSON
        (`["a", "b"]`, `{"k": 1}`, `42`, `true`). Пытаемся `json.loads`, при
        неудаче — оставляем строкой.
        """
        results: list[tuple[str, str]] = []
        for block in _MINIMAX_BLOCK_RE.finditer(text):
            inner = block.group(1)
            for inv in _MINIMAX_INVOKE_RE.finditer(inner):
                name = inv.group(1).strip()
                if not name:
                    continue
                body = inv.group(2)
                kv: dict[str, Any] = {}
                for pm in _MINIMAX_PARAM_RE.finditer(body):
                    key = pm.group(1).strip()
                    raw = pm.group(2).strip("\n").strip()
                    try:
                        kv[key] = json.loads(raw)
                    except (json.JSONDecodeError, ValueError):
                        kv[key] = raw
                if kv:
                    results.append((name, json.dumps(kv, ensure_ascii=False)))
        return results

    @staticmethod
    def _parse_deepseek_native_calls(text: str) -> list[tuple[str, str]]:
        """Парсит DeepSeek-V3.x native с спец-юникод-маркерами.

        Формат: `<｜tool▁calls▁begin｜><｜tool▁call▁begin｜>NAME<｜tool▁sep｜>JSON<｜tool▁call▁end｜>...<｜tool▁calls▁end｜>`.
        Содержимое после `<｜tool▁sep｜>` обязано быть валидным JSON-объектом.
        """
        results: list[tuple[str, str]] = []
        if "\uff5ctool\u2581call\u2581begin\uff5c>" not in text:
            return results
        for m in _DS_TOOL_CALL_RE.finditer(text):
            name = m.group(1).strip()
            payload = m.group(2).strip()
            if not name:
                continue
            try:
                parsed = json.loads(payload)
            except json.JSONDecodeError:
                continue
            if not isinstance(parsed, dict):
                continue
            results.append((name, json.dumps(parsed, ensure_ascii=False)))
        return results

    @staticmethod
    def _parse_named_json_calls(text: str) -> list[tuple[str, str]]:
        """Парсит формат `<tool_call><NAME>{json}</NAME></tool_call>`.

        Имя инструмента — имя XML-тега, аргументы — JSON-объект внутри.
        От XML-nested отличаем по тому, что содержимое тега должно начинаться
        с `{` и парситься как валидный JSON-объект.
        """
        results: list[tuple[str, str]] = []
        skip_names = {"name", "arguments", "tool_call", "thinking", "think", "reasoning", "thought"}
        for block in _TOOL_CALL_XML_BLOCK_RE.finditer(text):
            inner = block.group(1)
            for m in _TOOL_CALL_NAMED_BODY_RE.finditer(inner):
                name = m.group(1).strip()
                payload = m.group(2).strip()
                if not name or name.lower() in skip_names:
                    continue
                if not payload.startswith("{"):
                    continue
                try:
                    parsed = json.loads(payload)
                except json.JSONDecodeError:
                    continue
                if not isinstance(parsed, dict):
                    continue
                results.append((name, json.dumps(parsed, ensure_ascii=False)))
        return results

    @staticmethod
    def _parse_glm_calls(text: str) -> list[tuple[str, str]]:
        """Парсит ChatGLM-style: `<tool_call>NAME<arg_key>K</arg_key><arg_value>V</arg_value>…</tool_call>`.

        Имя инструмента — голый идентификатор перед первым `<arg_key>`,
        аргументы — последовательность пар. Внутри `<arg_value>` могут быть
        любые символы, в т.ч. `>`, `\\"` и переводы строк, но не закрывающий тег.
        """
        results: list[tuple[str, str]] = []
        for block in _TOOL_CALL_XML_BLOCK_RE.finditer(text):
            inner = block.group(1)
            name_match = _TOOL_CALL_GLM_NAME_RE.match(inner)
            if not name_match:
                continue
            name = name_match.group(1).strip()
            if not name or name.lower() in {"name", "arguments", "tool_call"}:
                continue
            kv: dict[str, Any] = {}
            for kv_m in _TOOL_CALL_GLM_KV_RE.finditer(inner):
                key = kv_m.group(1).strip()
                raw_val = kv_m.group(2)
                val = raw_val.replace('\\"', '"').replace("\\\\", "\\")
                if key:
                    kv[key] = val
            if kv:
                results.append((name, json.dumps(kv, ensure_ascii=False)))
        return results

    @staticmethod
    def _parse_attr_calls(text: str) -> list[tuple[str, str]]:
        """Парсит DeepSeek attribute-style: `<tool_call><bash key="v"/></tool_call>`.

        Имя инструмента — сам элемент, аргументы — его XML-атрибуты.
        Поддерживается и самозакрытый тег `<name a="v"/>`, и парный
        `<name a="v"></name>`. Внутри значений атрибутов разрешены
        экранированные кавычки (`\\"`), `>` и `/` (например `2>/dev/null`),
        поэтому конец тега ищем stateful-сканером, а не regex'ом.
        """
        results: list[tuple[str, str]] = []
        skip_names = {"name", "arguments", "tool_call"}

        for block in _TOOL_CALL_XML_BLOCK_RE.finditer(text):
            inner = block.group(1)
            n = len(inner)
            i = 0
            while i < n:
                head = _TOOL_CALL_NAME_HEAD_RE.search(inner, i)
                if not head:
                    break
                name = head.group(1)
                attr_start = head.end()
                if name.lower() in skip_names:
                    i = attr_start
                    continue

                j = attr_start
                in_str = False
                escaped = False
                close_pos = -1
                self_closing = False
                while j < n:
                    c = inner[j]
                    if in_str:
                        if escaped:
                            escaped = False
                        elif c == "\\":
                            escaped = True
                        elif c == '"':
                            in_str = False
                        j += 1
                        continue
                    if c == '"':
                        in_str = True
                        j += 1
                        continue
                    if c == "/":
                        k = j + 1
                        while k < n and inner[k].isspace():
                            k += 1
                        if k < n and inner[k] == ">":
                            close_pos = k + 1
                            self_closing = True
                            break
                    if c == ">":
                        close_pos = j + 1
                        self_closing = False
                        break
                    j += 1

                if close_pos < 0:
                    break

                attrs_text = inner[attr_start:j]
                next_pos = close_pos
                if not self_closing:
                    close_tag = re.compile(
                        r"\s*<\s*/\s*" + re.escape(name) + r"\s*>",
                        re.DOTALL | re.IGNORECASE,
                    )
                    tail = close_tag.match(inner, close_pos)
                    if not tail:
                        i = close_pos
                        continue
                    next_pos = tail.end()

                kv: dict[str, Any] = {}
                for kv_m in _TOOL_CALL_ATTR_KV_RE.finditer(attrs_text):
                    key = kv_m.group(1).strip()
                    raw_val = kv_m.group(2)
                    val = raw_val.replace('\\"', '"').replace("\\\\", "\\")
                    if key:
                        kv[key] = val

                if kv:
                    results.append((name, json.dumps(kv, ensure_ascii=False)))

                i = next_pos
        return results

    @staticmethod
    def _parse_child_xml_calls(text: str) -> list[tuple[str, str]]:
        """Парсит Claude/Cline-style child-tag XML:
        `<tool_call><NAME><k1>v1</k1><k2>v2</k2></NAME></tool_call>`.

        Имя инструмента — первый «осмысленный» child-тег внутри `<tool_call>`,
        аргументы — вложенные `<key>value</key>` пары. DeepSeek-V3.2 в
        OpenClaw регулярно выбирает этот формат (так его учили на
        Claude/Roo/Cline-датасетах) — без отдельного парсера блок утекает
        как plain text и tool не выполняется.

        Распознаётся ТОЛЬКО когда у child-тега есть хотя бы одна KV-пара —
        иначе уступаем место `_parse_xml_calls` (он умеет голый
        `<name>X</name><arguments>{…}</arguments>` ).
        """
        skip_names = {
            "name", "arguments", "tool_call", "thinking", "think",
            "reasoning", "thought", "parameters", "params",
        }
        results: list[tuple[str, str]] = []
        for block in _TOOL_CALL_XML_BLOCK_RE.finditer(text):
            inner = block.group(1)
            pos = 0
            while pos < len(inner):
                m = _TOOL_CALL_CHILD_OPEN_RE.search(inner, pos)
                if not m:
                    break
                name = m.group(1).strip()
                pos = m.end()
                if name.lower() in skip_names:
                    continue
                close_re = re.compile(
                    rf"<\s*/\s*{re.escape(name)}\s*>", re.DOTALL
                )
                close_m = close_re.search(inner, pos)
                if not close_m:
                    continue
                body = inner[pos:close_m.start()]
                pos = close_m.end()

                kv: dict[str, Any] = {}
                for kv_m in _TOOL_CALL_XML_KV_RE.finditer(body):
                    key = kv_m.group(1).strip()
                    val = kv_m.group(2)
                    if key and key.lower() not in skip_names:
                        kv[key] = val
                if kv:
                    results.append((name, json.dumps(kv, ensure_ascii=False)))
        return results

    @staticmethod
    def _parse_xml_calls(text: str) -> list[tuple[str, str]]:
        """Парсит Anthropic/DeepSeek XML-формат `<tool_call><name>...</name><arguments>...</arguments></tool_call>`.

        Внутри `<arguments>`:
          1) сперва пробуем как JSON (модель могла прислать JSON в XML-обёртке);
          2) иначе собираем плоские пары `<key>value</key>` в `{key: value}`.

        Это нужно потому что часть моделей на IFT (DeepSeek-V3.2, Qwen3.5) шлют
        именно такой формат вместо ожидаемого Hermes JSON, и наш базовый
        парсер их пропускает — клиенту на выход уходит сырой XML текстом,
        и инструменты не выполняются.
        """
        results: list[tuple[str, str]] = []
        for block in _TOOL_CALL_XML_BLOCK_RE.finditer(text):
            inner = block.group(1)
            name_m = _TOOL_CALL_XML_NAME_RE.search(inner)
            args_m = _TOOL_CALL_XML_ARGS_RE.search(inner)
            if not name_m:
                continue
            name = name_m.group(1).strip()
            if not name:
                continue

            args_str = "{}"
            if args_m:
                raw = args_m.group(1).strip()
                if raw.startswith("{") and raw.endswith("}"):
                    try:
                        json.loads(raw)
                        args_str = raw
                    except json.JSONDecodeError:
                        pass
                if args_str == "{}":
                    kv: dict[str, Any] = {}
                    for kv_m in _TOOL_CALL_XML_KV_RE.finditer(raw):
                        key = kv_m.group(1).strip()
                        val = kv_m.group(2).strip()
                        if key and key.lower() != "arguments":
                            kv[key] = val
                    if kv:
                        args_str = json.dumps(kv, ensure_ascii=False)
                    elif raw and raw != "{}":
                        return []

            results.append((name, args_str))
        return results

    @staticmethod
    def _try_parse_legacy(text: str) -> Optional[tuple[str, str]]:
        s = text.lstrip()
        for pat in _TOOL_LEAK_PATTERNS:
            m = pat.match(s)
            if not m:
                continue
            rest = s[m.end():]
            args = _extract_balanced_json_object(rest)
            if args is None:
                continue
            return m.group(1), args
        return None

    @staticmethod
    def _build_tool_call_chunks(
        calls: list[tuple[str, str]], base: dict[str, Any]
    ) -> list[dict[str, Any]]:
        """Один body-чанк со всеми tool_calls + один finalizer."""
        common = {
            "object": base.get("object", "chat.completion.chunk"),
            "created": base.get("created"),
            "model": base.get("model"),
        }
        tool_calls = []
        for i, (name, arguments) in enumerate(calls):
            arguments = _tool_arguments_json(arguments)
            if arguments is None:
                return _ToolCallStreamRewriter._build_parse_fail_chunks(base)
            tool_calls.append({
                "index": i,
                "id": f"call_proxy_{uuid.uuid4().hex[:24]}",
                "type": "function",
                "function": {"name": name, "arguments": arguments},
            })
        opener = {
            **common,
            "choices": [{
                "index": 0,
                "delta": {
                    "role": "assistant",
                    "content": "",
                    "tool_calls": tool_calls,
                },
            }],
        }
        finisher = {
            **common,
            "choices": [{"index": 0, "delta": {}, "finish_reason": "tool_calls"}],
        }
        return [opener, finisher]

    @staticmethod
    def _build_parse_fail_chunks(base: dict[str, Any]) -> list[dict[str, Any]]:
        """Не отдаём сырой <tool_call> — короткое сообщение пользователю."""
        common = {
            "object": base.get("object", "chat.completion.chunk"),
            "created": base.get("created"),
            "model": base.get("model"),
        }
        opener = {
            **common,
            "choices": [{
                "index": 0,
                "delta": {
                    "role": "assistant",
                    "content": _TOOL_CALL_PARSE_FAIL_USER_MSG,
                },
            }],
        }
        finisher = {
            **common,
            "choices": [{"index": 0, "delta": {}, "finish_reason": "stop"}],
        }
        return [opener, finisher]

    @staticmethod
    def _buffer_looks_like_tool_call_leak(buffered: str) -> bool:
        lower = buffered.lower()
        return "<tool_call" in lower or "<minimax:tool_call" in lower

    def _flush_as_text(self) -> list[dict[str, Any]]:
        held = self._held_chunks
        self._reset()
        return held

    def _reset(self) -> None:
        self._buffered = ""
        self._holding = False
        self._held_chunks = []

    def _try_finalize(self, base_chunk: dict[str, Any]) -> Optional[list[dict[str, Any]]]:
        """Пытается разобрать буфер. Возвращает list чанков или None если не вышло.

        Порядок парсеров — от самых однозначных (с уникальными маркерами) к
        более общим. DeepSeek native и MiniMax native имеют невозможные в
        обычном тексте маркеры, поэтому проверяются первыми.
        """
        # A malformed Hermes block must not let another parser execute a subset.
        hermes_batch = _parse_hermes_tool_call_batch(self._buffered)
        if hermes_batch == []:
            return None

        # 0a. DeepSeek-V3.x native: спец-юникод-маркеры <｜tool▁call▁begin｜>...
        ds_native = self._parse_deepseek_native_calls(self._buffered)
        if ds_native:
            log.info(
                "stream rewriter: parsed %d DeepSeek-native tool_call(s): %s",
                len(ds_native), [c[0] for c in ds_native],
            )
            _dump_to_file(
                "STREAM REWRITER: deepseek-native parsed",
                {
                    "calls": [
                        {"name": n, "arguments_preview": a[:200]} for n, a in ds_native
                    ],
                    "buffered_len": len(self._buffered),
                    "buffered_head": self._buffered[:500],
                },
            )
            base = self._held_chunks[-1] if self._held_chunks else base_chunk
            self._reset()
            return self._build_tool_call_chunks(ds_native, base)

        # 0b. MiniMax-M2 native: <minimax:tool_call><invoke name="X"><parameter>...
        mm_calls = self._parse_minimax_calls(self._buffered)
        if mm_calls:
            log.info(
                "stream rewriter: parsed %d MiniMax-native tool_call(s): %s",
                len(mm_calls), [c[0] for c in mm_calls],
            )
            _dump_to_file(
                "STREAM REWRITER: minimax-native parsed",
                {
                    "calls": [
                        {"name": n, "arguments_preview": a[:200]} for n, a in mm_calls
                    ],
                    "buffered_len": len(self._buffered),
                    "buffered_head": self._buffered[:500],
                },
            )
            base = self._held_chunks[-1] if self._held_chunks else base_chunk
            self._reset()
            return self._build_tool_call_chunks(mm_calls, base)

        # 1. Hermes/Qwen3 JSON-формат: <tool_call>{...}</tool_call>.
        calls = hermes_batch
        if calls:
            log.info(
                "stream rewriter: parsed %d <tool_call> JSON block(s): %s",
                len(calls), [c[0] for c in calls],
            )
            _dump_to_file(
                "STREAM REWRITER: hermes <tool_call> parsed",
                {
                    "calls": [
                        {"name": n, "arguments_preview": a[:200]} for n, a in calls
                    ],
                    "buffered_len": len(self._buffered),
                    "buffered_head": self._buffered[:500],
                },
            )
            base = self._held_chunks[-1] if self._held_chunks else base_chunk
            self._reset()
            return self._build_tool_call_chunks(calls, base)

        # 1a-qwen. Родной XML Qwen: <function=exec><parameter=command>…</parameter></function>.
        qwen_calls = self._parse_qwen_fn_calls(self._buffered)
        if qwen_calls:
            log.info(
                "stream rewriter: parsed %d Qwen <function=> tool_call(s): %s",
                len(qwen_calls), [c[0] for c in qwen_calls],
            )
            _dump_to_file(
                "STREAM REWRITER: qwen <function=> parsed",
                {
                    "calls": [
                        {"name": n, "arguments_preview": a[:200]} for n, a in qwen_calls
                    ],
                    "buffered_len": len(self._buffered),
                    "buffered_head": self._buffered[:500],
                },
            )
            base = self._held_chunks[-1] if self._held_chunks else base_chunk
            self._reset()
            return self._build_tool_call_chunks(qwen_calls, base)

        # 1a-named. DeepSeek named-JSON: <tool_call><NAME>{json}</NAME></tool_call>.
        # Имя инструмента — XML-тег, аргументы — JSON-объект внутри.
        named_calls = self._parse_named_json_calls(self._buffered)
        if named_calls:
            log.info(
                "stream rewriter: parsed %d <tool_call> named-JSON block(s): %s",
                len(named_calls), [c[0] for c in named_calls],
            )
            _dump_to_file(
                "STREAM REWRITER: named-JSON <tool_call> parsed",
                {
                    "calls": [
                        {"name": n, "arguments_preview": a[:200]} for n, a in named_calls
                    ],
                    "buffered_len": len(self._buffered),
                    "buffered_head": self._buffered[:500],
                },
            )
            base = self._held_chunks[-1] if self._held_chunks else base_chunk
            self._reset()
            return self._build_tool_call_chunks(named_calls, base)

        # 1a-glm. ChatGLM-формат: <tool_call>NAME<arg_key>K</arg_key><arg_value>V</arg_value>…</tool_call>.
        # GLM-4.5/GLM-5.1 обучены именно на нём.
        glm_calls = self._parse_glm_calls(self._buffered)
        if glm_calls:
            log.info(
                "stream rewriter: parsed %d <tool_call> GLM block(s): %s",
                len(glm_calls), [c[0] for c in glm_calls],
            )
            _dump_to_file(
                "STREAM REWRITER: glm <tool_call> parsed",
                {
                    "calls": [
                        {"name": n, "arguments_preview": a[:200]} for n, a in glm_calls
                    ],
                    "buffered_len": len(self._buffered),
                    "buffered_head": self._buffered[:500],
                },
            )
            base = self._held_chunks[-1] if self._held_chunks else base_chunk
            self._reset()
            return self._build_tool_call_chunks(glm_calls, base)

        # 1b0. Claude/Cline-style child-tag XML:
        # <tool_call><edit><filePath>...</filePath><oldString>...</oldString>...</edit></tool_call>.
        # Имя инструмента — сам первый child-тег, аргументы — вложенные
        # KV-теги. DeepSeek-V3.2 в OpenClaw часто выбирает именно его
        # (обучен на Claude/Roo/Cline-датасетах). Парсим ДО легаси-XML,
        # потому что иначе `_parse_xml_calls` ищет жёсткие `<name>` /
        # `<arguments>` обёртки, не находит их и блок утекает как текст.
        child_xml_calls = self._parse_child_xml_calls(self._buffered)
        if child_xml_calls:
            log.info(
                "stream rewriter: parsed %d <tool_call> child-XML block(s): %s",
                len(child_xml_calls), [c[0] for c in child_xml_calls],
            )
            _dump_to_file(
                "STREAM REWRITER: child-xml <tool_call> parsed",
                {
                    "calls": [
                        {"name": n, "arguments_preview": a[:200]} for n, a in child_xml_calls
                    ],
                    "buffered_len": len(self._buffered),
                    "buffered_head": self._buffered[:500],
                },
            )
            base = self._held_chunks[-1] if self._held_chunks else base_chunk
            self._reset()
            return self._build_tool_call_chunks(child_xml_calls, base)

        # 1b. Anthropic/DeepSeek XML-формат: <tool_call><name>X</name><arguments>...</arguments></tool_call>.
        # Часть моделей IFT (DeepSeek-V3.2, Qwen3.5) выбирают именно его,
        # игнорируя инструкцию использовать JSON.
        xml_calls = self._parse_xml_calls(self._buffered)
        if xml_calls:
            log.info(
                "stream rewriter: parsed %d <tool_call> XML block(s): %s",
                len(xml_calls), [c[0] for c in xml_calls],
            )
            _dump_to_file(
                "STREAM REWRITER: xml <tool_call> parsed",
                {
                    "calls": [
                        {"name": n, "arguments_preview": a[:200]} for n, a in xml_calls
                    ],
                    "buffered_len": len(self._buffered),
                    "buffered_head": self._buffered[:500],
                },
            )
            base = self._held_chunks[-1] if self._held_chunks else base_chunk
            self._reset()
            return self._build_tool_call_chunks(xml_calls, base)

        # 1c. DeepSeek attribute-style: <tool_call><bash command="..." /></tool_call>.
        # DeepSeek-V3.2 регулярно выбирает именно этот формат — имя инструмента
        # подставляется как сам тег, а аргументы летят XML-атрибутами.
        attr_calls = self._parse_attr_calls(self._buffered)
        if attr_calls:
            log.info(
                "stream rewriter: parsed %d <tool_call> attr block(s): %s",
                len(attr_calls), [c[0] for c in attr_calls],
            )
            _dump_to_file(
                "STREAM REWRITER: attr <tool_call> parsed",
                {
                    "calls": [
                        {"name": n, "arguments_preview": a[:200]} for n, a in attr_calls
                    ],
                    "buffered_len": len(self._buffered),
                    "buffered_head": self._buffered[:500],
                },
            )
            base = self._held_chunks[-1] if self._held_chunks else base_chunk
            self._reset()
            return self._build_tool_call_chunks(attr_calls, base)

        # 2. Legacy: одиночный inline-tool-history маркер.
        legacy = self._try_parse_legacy(self._buffered)
        if legacy:
            name, args = legacy
            log.info("stream rewriter: rescued legacy tool_call name=%s", name)
            _dump_to_file(
                "STREAM REWRITER: legacy tool_call rescued",
                {
                    "name": name,
                    "arguments_preview": args[:200],
                    "buffered_head": self._buffered[:500],
                },
            )
            base = self._held_chunks[-1] if self._held_chunks else base_chunk
            self._reset()
            return self._build_tool_call_chunks([(name, args)], base)

        return None

    def feed(self, chunk: dict[str, Any]) -> list[dict[str, Any]]:
        choices = chunk.get("choices") or []
        if not choices:
            return [chunk]
        choice = choices[0]
        delta = choice.get("delta") or {}
        finish_reason = choice.get("finish_reason")

        # Если модель сама сделала нативный tool_call — отпускаем буфер
        # как есть и пропускаем чанк без вмешательства.
        if delta.get("tool_calls") or delta.get("function_call"):
            return self._flush_as_text() + [chunk]

        delta_text = delta.get("content")
        if isinstance(delta_text, str) and delta_text:
            self._buffered += delta_text
            if not self._holding and self._looks_leaky(self._buffered):
                self._holding = True

        if self._holding:
            self._held_chunks.append(chunk)
            if finish_reason:
                parsed = self._try_finalize(chunk)
                if parsed is not None:
                    return parsed
                # Парсинг не удался — отпускаем накопленные чанки как текст.
                log.warning(
                    "stream rewriter: looked leaky but failed to parse "
                    "(buffered=%d chars, finish_reason=%s); flushing as text",
                    len(self._buffered), finish_reason,
                )
                _dump_to_file(
                    "STREAM REWRITER: parse FAILED (flushing as text)",
                    {
                        "finish_reason": finish_reason,
                        "buffered_len": len(self._buffered),
                        "buffered_full": self._buffered,
                    },
                )
                leaked = self._buffered
                base = self._held_chunks[-1] if self._held_chunks else chunk
                if self._buffer_looks_like_tool_call_leak(leaked):
                    self._reset()
                    log.warning(
                        "stream rewriter: parse failed for tool_call leak; "
                        "returning user-facing fallback instead of raw XML",
                    )
                    return self._build_parse_fail_chunks(base)
                return self._flush_as_text()
            return []

        return [chunk]

    def drain(self) -> list[dict[str, Any]]:
        """Если стрим закрылся, не дойдя до finish_reason, отдаём что есть."""
        if not self._held_chunks:
            return []
        if self._buffered:
            parsed = self._try_finalize(self._held_chunks[-1])
            if parsed is not None:
                return parsed
            leaked = self._buffered
            base = self._held_chunks[-1]
            if self._buffer_looks_like_tool_call_leak(leaked):
                log.warning(
                    "stream rewriter: parse failed after stream closed without finish_reason "
                    "(buffered=%d chars)", len(leaked),
                )
                _dump_to_file(
                    "STREAM REWRITER: parse FAILED (stream closed)",
                    {"finish_reason": "missing_finish_reason", "buffered_len": len(leaked), "buffered_full": leaked},
                )
                self._reset()
                return self._build_parse_fail_chunks(base)
        return self._flush_as_text()


# ---------------------------------------------------------------------------
# Прокси к GigaChat
# ---------------------------------------------------------------------------


def _gigachat_url(path: str) -> str:
    return f"{Settings.BASE_URL}{Settings.API_PREFIX}/{path.lstrip('/')}"


async def _build_outgoing_headers(client_authorization: Optional[str]) -> dict[str, str]:
    headers: dict[str, str] = {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "RqUID": str(uuid.uuid4()),
    }
    auth = await token_manager.get(client_authorization)
    if auth:
        headers["Authorization"] = auth
    return headers


def _check_proxy_auth(request: Request) -> None:
    if not Settings.PROXY_API_KEY:
        return
    header = request.headers.get("authorization", "")
    expected = f"Bearer {Settings.PROXY_API_KEY}"
    if header != expected:
        raise HTTPException(status_code=401, detail="Unauthorized")


def _is_invalid_json_400(err_text: str) -> bool:
    try:
        data = json.loads(err_text)
        return data.get("status") == 400 and "invalid JSON syntax" in str(data.get("message", ""))
    except Exception:
        return False


def _strip_think_from_chunk(
    chunk: dict[str, Any], stripper: _ThinkBlockStripper
) -> Optional[dict[str, Any]]:
    """
    Прогоняет `delta.content` через стриппер `<think>...</think>`. Возвращает:
      * сам chunk (возможно, с подменённым content), если что-то осталось;
      * `None`, если после вырезания контент пустой и в чанке больше ничего
        нет (отдавать клиенту такое — лишний шум).

    Если включён `EMIT_REASONING_CONTENT`, накопленный текст из `<think>`
    выставляется в `delta.reasoning_content` — нативное поле AI SDK
    `@ai-sdk/openai-compatible` (его читает OpenCode и DeepSeek-R1-клиенты).
    """
    choices = chunk.get("choices")
    if not isinstance(choices, list) or not choices:
        return chunk

    emit_reasoning = Settings.EMIT_REASONING_CONTENT

    has_anything = False
    for ch in choices:
        if not isinstance(ch, dict):
            has_anything = True
            continue

        delta = ch.get("delta")
        if not isinstance(delta, dict):
            has_anything = True
            continue

        content = delta.get("content")
        if isinstance(content, str):
            cleaned = stripper.feed(content)
            if cleaned:
                delta["content"] = cleaned
            else:
                delta.pop("content", None)
            if emit_reasoning:
                reasoning = stripper.pop_reasoning()
                if reasoning:
                    prev = delta.get("reasoning_content")
                    delta["reasoning_content"] = (
                        (prev + reasoning) if isinstance(prev, str) else reasoning
                    )

        if (
            delta.get("content")
            or delta.get("reasoning_content")
            or delta.get("tool_calls")
            or delta.get("function_call")
            or delta.get("role")
        ):
            has_anything = True
        if ch.get("finish_reason"):
            has_anything = True

    return chunk if has_anything else None


def _drain_think_to_chunk(stripper: _ThinkBlockStripper) -> Optional[dict[str, Any]]:
    """Если стриппер скопил недоотданный текст — вернёт его одним чанком.

    Если включён `EMIT_REASONING_CONTENT`, заодно подмешивает остаток
    reasoning-текста (хвост незакрытого `<think>` блока) как
    `delta.reasoning_content`.
    """
    leftover = stripper.drain()
    delta: dict[str, Any] = {"role": "assistant"}
    if leftover:
        delta["content"] = leftover
    if Settings.EMIT_REASONING_CONTENT:
        reasoning = stripper.pop_reasoning()
        if reasoning:
            delta["reasoning_content"] = reasoning
    if "content" not in delta and "reasoning_content" not in delta:
        return None
    return {
        "object": "chat.completion.chunk",
        "choices": [
            {
                "index": 0,
                "delta": delta,
            }
        ],
    }


_NETWORK_RETRY_EXC = (
    httpx.ConnectError,
    httpx.ConnectTimeout,
    httpx.ReadError,
    httpx.ReadTimeout,
    httpx.RemoteProtocolError,
    httpx.NetworkError,
)


class _UpstreamProbe:
    """Тайминги одного запроса к upstream: предупреждения [wait] и итоговая строка."""

    def __init__(self, label: str) -> None:
        self.label = label
        self.t0 = self.last = time.monotonic()
        self.t_headers: Optional[float] = None
        self.t_first: Optional[float] = None
        self.status: Optional[int] = None
        self.upstream_id = "-"
        self.chunks = 0
        self.usage: Any = None
        self._watch_task: Optional[asyncio.Task] = None

    def on_headers(self, response: httpx.Response) -> None:
        self.t_headers = self.last = time.monotonic()
        self.status = response.status_code
        self.upstream_id = (
            response.headers.get("x-request-id") or response.headers.get("x-session-id") or "-"
        )

    def on_data(self, chunk: Any = None) -> None:
        self.last = time.monotonic()
        self.chunks += 1
        if self.t_first is None:
            self.t_first = self.last
        if isinstance(chunk, dict) and chunk.get("usage"):
            self.usage = chunk["usage"]

    def at(self, t: Optional[float]) -> str:
        return f"{t - self.t0:.1f}s" if t is not None else "-"

    def total(self) -> str:
        return f"{time.monotonic() - self.t0:.1f}s"

    def usage_str(self) -> str:
        u = self.usage
        if not isinstance(u, dict):
            return "-"
        return f"{u.get('prompt_tokens', '?')}/{u.get('completion_tokens', '?')}"

    async def watch(self) -> None:
        step = Settings.STALL_WARN_SECONDS
        next_warn = step
        while True:
            await asyncio.sleep(1)
            now = time.monotonic()
            idle = now - self.last
            if idle < step:
                next_warn = step
                continue
            if idle < next_warn:
                continue
            next_warn += step
            if self.t_headers is None:
                what = "no response from upstream yet"
            elif self.t_first is None:
                what = f"HTTP {self.status}, waiting for first token"
            else:
                what = f"stream stalled after {self.chunks} chunks"
            log.warning("[wait] %s: %s; silent %.0fs, total %.0fs", self.label, what, idle, now - self.t0)

    def start_watch(self) -> None:
        if Settings.STALL_WARN_SECONDS > 0:
            self._watch_task = asyncio.create_task(self.watch())

    def stop_watch(self) -> None:
        if self._watch_task is not None:
            self._watch_task.cancel()
            self._watch_task = None


def _content_chars(chunks: list[dict[str, Any]]) -> int:
    n = 0
    for ch in chunks:
        for choice in ch.get("choices") or [] if isinstance(ch, dict) else []:
            delta = choice.get("delta") if isinstance(choice, dict) else None
            if isinstance(delta, dict) and isinstance(delta.get("content"), str):
                n += len(delta["content"])
    return n


async def _stream_chat(
    url: str,
    headers: dict[str, str],
    payload: dict[str, Any],
    _retry_429_attempt: int = 0,
    _retry_network_attempt: int = 0,
) -> AsyncIterator[bytes]:
    timeout = httpx.Timeout(Settings.STREAM_TIMEOUT)
    collected_chunks: list[dict[str, Any]] = []
    rewriter = _ToolCallStreamRewriter()
    hide_think = Settings.HIDE_THINK_BLOCKS and _is_thinking_model(payload.get("model"))
    think_stripper = _ThinkBlockStripper() if hide_think else None
    # Флаг: «мы уже начали отдавать клиенту чанки». Если упало ПОСЛЕ начала
    # стрима — ретраить нельзя (получится дубль ответа). Если упало ДО —
    # лечится повтором с backoff.
    stream_started = False
    agent = _openclaw_context_from_messages(payload.get("messages")).get("agent") or "?"
    probe = _UpstreamProbe(f"agent={agent} model={payload.get('model')}")
    probe.start_watch()
    # Итог для строки [stream]; "?" в finally = генератор закрыли снаружи
    # (клиент OpenClaw отвалился / отменил запрос).
    outcome = "?"
    done_seen = False
    try:
        async with http_client.stream(
            "POST", url, headers=headers, json=payload, timeout=timeout
        ) as response:
            probe.on_headers(response)
            if response.status_code >= 400:
                err_body = await response.aread()
                err_text = err_body.decode("utf-8", "ignore")

                if response.status_code == 429 and _retry_429_attempt < Settings.RETRY_429_MAX_ATTEMPTS:
                    delay = Settings.RETRY_429_INITIAL_DELAY * (2 ** _retry_429_attempt)
                    log.warning(
                        "Upstream 429 rate limit (attempt %d/%d); retrying in %.1fs",
                        _retry_429_attempt + 1,
                        Settings.RETRY_429_MAX_ATTEMPTS,
                        delay,
                    )
                    _dump_to_file(f"UPSTREAM 429 (will retry in {delay:.1f}s)", err_text)
                    outcome = "retry_429"
                    probe.stop_watch()
                    await asyncio.sleep(delay)
                    async for chunk in _stream_chat(url, headers, payload, _retry_429_attempt + 1):
                        yield chunk
                    return

                if (
                    Settings.RETRY_STRIP_ON_400
                    and response.status_code == 400
                    and _is_invalid_json_400(err_text)
                    and isinstance(payload.get("messages"), list)
                ):
                    log.warning("Upstream 400 invalid JSON; retrying without tool history")
                    _dump_to_file("UPSTREAM STREAM ERROR 400 (will retry)", err_text)
                    retry_payload = dict(payload)
                    retry_payload["messages"] = _strip_tool_history(payload["messages"])
                    if Settings.MERGE_CONSECUTIVE_ROLES:
                        retry_payload["messages"] = _merge_consecutive_roles(retry_payload["messages"])
                    _dump_to_file("REQUEST -> upstream (retry)", retry_payload)
                    outcome = "retry_400_strip_tools"
                    probe.stop_watch()
                    async for chunk in _stream_chat(url, headers, retry_payload):
                        yield chunk
                    return

                fallback = _with_fallback_model(payload) if _model_unavailable(response.status_code, err_text) else None
                if fallback is not None:
                    log.warning(
                        "Model %s unavailable (%s); answering with %s",
                        payload.get("model"),
                        response.status_code,
                        fallback["model"],
                    )
                    _dump_to_file("UPSTREAM MODEL MISSING (will retry)", err_text)
                    outcome = f"fallback_model->{fallback['model']}"
                    probe.stop_watch()
                    async for chunk in _stream_chat(url, headers, fallback):
                        yield chunk
                    return

                log.error("Upstream stream error %s: %s", response.status_code, _truncate(err_text))
                _dump_to_file(f"UPSTREAM STREAM ERROR {response.status_code}", err_text)
                outcome = f"upstream_error_{response.status_code}"
                err = json.dumps(
                    {"error": {"message": err_text, "type": "upstream_error"}}
                )
                yield f"data: {err}\n\n".encode("utf-8")
                yield b"data: [DONE]\n\n"
                return

            async for raw_line in response.aiter_lines():
                if raw_line is None:
                    continue
                line = raw_line.rstrip()
                if not line:
                    yield b"\n"
                    continue
                if not line.startswith("data:"):
                    yield (line + "\n").encode("utf-8")
                    continue

                data = line[5:].lstrip()
                if data == "[DONE]":
                    done_seen = True
                    if think_stripper is not None:
                        tail = _drain_think_to_chunk(think_stripper)
                        if tail is not None:
                            collected_chunks.append(tail)
                            yield f"data: {json.dumps(tail, ensure_ascii=False)}\n\n".encode("utf-8")
                    for tail_chunk in rewriter.drain():
                        collected_chunks.append(tail_chunk)
                        out_tail = json.dumps(tail_chunk, ensure_ascii=False)
                        if Settings.STREAM_CHUNK_LOG:
                            log.info("rewriter tail -> %s", _truncate(out_tail))
                        yield f"data: {out_tail}\n\n".encode("utf-8")
                    yield b"data: [DONE]\n\n"
                    continue
                try:
                    chunk = json.loads(data)
                    probe.on_data(chunk)
                    transformed = transform_stream_chunk(chunk)
                    out_chunks: list[dict[str, Any]] = []
                    for sub in transformed:
                        if think_stripper is not None:
                            sub_clean = _strip_think_from_chunk(sub, think_stripper)
                            if sub_clean is None:
                                continue
                            sub = sub_clean
                        out_chunks.extend(rewriter.feed(sub))
                except Exception:
                    yield f"data: {data}\n\n".encode("utf-8")
                    continue

                for out_chunk in out_chunks:
                    collected_chunks.append(out_chunk)
                    out = json.dumps(out_chunk, ensure_ascii=False)
                    if Settings.STREAM_CHUNK_LOG:
                        log.info("upstream chunk -> %s", _truncate(out))
                    # Пишем tool_call событие как только видим имя инструмента
                    for tc_name, tc_args in _detect_tool_calls_in_chunk(out_chunk):
                        _write_tool_event(
                            agent=_openclaw_context_from_messages(payload.get("messages")).get("agent") or "?",
                            event="tool_call",
                            tool=tc_name,
                            detail=tc_args,
                        )
                    stream_started = True
                    yield f"data: {out}\n\n".encode("utf-8")
            outcome = "ok" if done_seen else "upstream_eof_without_done"
    except _NETWORK_RETRY_EXC as net_exc:
        # Сеть отвалилась. Если до старта стрима — ретраим (клиенту
        # ещё ничего не отдали, дубля не будет). Если уже отдали часть —
        # заворачиваем как обычную ошибку, ретрай небезопасен.
        if not stream_started and _retry_network_attempt < Settings.RETRY_NETWORK_MAX_ATTEMPTS:
            delay = Settings.RETRY_NETWORK_INITIAL_DELAY * (2 ** _retry_network_attempt)
            log.warning(
                "Upstream network error (%s) before stream started; retry %d/%d in %.1fs",
                type(net_exc).__name__,
                _retry_network_attempt + 1,
                Settings.RETRY_NETWORK_MAX_ATTEMPTS,
                delay,
            )
            _dump_to_file(
                f"UPSTREAM NETWORK ERROR (will retry in {delay:.1f}s)",
                f"{type(net_exc).__name__}: {net_exc}",
            )
            outcome = f"retry_network_{type(net_exc).__name__}"
            probe.stop_watch()
            await asyncio.sleep(delay)
            async for chunk in _stream_chat(
                url,
                headers,
                payload,
                _retry_429_attempt,
                _retry_network_attempt + 1,
            ):
                yield chunk
            return
        log.error(
            "Upstream network error (%s) after %d retries (stream_started=%s)",
            type(net_exc).__name__,
            _retry_network_attempt,
            stream_started,
        )
        _dump_to_file(
            "UPSTREAM NETWORK ERROR (giving up)",
            f"{type(net_exc).__name__}: {net_exc} stream_started={stream_started}",
        )
        outcome = f"network_error_{type(net_exc).__name__}"
        err = json.dumps(
            {"error": {"message": f"Upstream unreachable: {net_exc}", "type": "network_error"}}
        )
        yield f"data: {err}\n\n".encode("utf-8")
        yield b"data: [DONE]\n\n"
        return
    except Exception as exc:
        log.exception("Stream error")
        _dump_to_file("STREAM EXCEPTION", str(exc))
        outcome = f"exception_{type(exc).__name__}"
        if think_stripper is not None:
            tail = _drain_think_to_chunk(think_stripper)
            if tail is not None:
                collected_chunks.append(tail)
                yield f"data: {json.dumps(tail, ensure_ascii=False)}\n\n".encode("utf-8")
        for tail_chunk in rewriter.drain():
            collected_chunks.append(tail_chunk)
            yield f"data: {json.dumps(tail_chunk, ensure_ascii=False)}\n\n".encode("utf-8")
        err = json.dumps({"error": {"message": str(exc), "type": "stream_error"}})
        yield f"data: {err}\n\n".encode("utf-8")
        yield b"data: [DONE]\n\n"
    finally:
        probe.stop_watch()
        if outcome == "?":
            outcome = "client_disconnected"
        if collected_chunks:
            _dump_to_file("STREAM CHUNKS (full)", collected_chunks)
        # Попытка, ушедшая в retry/fallback, итог не пишет — его пишет последняя.
        if Settings.PROXY_ACCESS_LOG and not outcome.startswith(("retry_", "fallback_")):
            fr = _finish_reason_from_chunks(collected_chunks) or "-"
            tnames = _tool_names_from_chunks(collected_chunks)
            tools_s = ",".join(tnames) if tnames else "-"
            log.log(
                logging.INFO if outcome == "ok" else logging.WARNING,
                "[stream] %s outcome=%s status=%s headers=%s first_token=%s total=%s "
                "finish=%s tools=%s chunks=%d chars=%d tokens(in/out)=%s upstream_id=%s",
                probe.label,
                outcome,
                probe.status if probe.status is not None else "-",
                probe.at(probe.t_headers),
                probe.at(probe.t_first),
                probe.total(),
                fr,
                tools_s,
                len(collected_chunks),
                _content_chars(collected_chunks),
                probe.usage_str(),
                probe.upstream_id,
            )


# ---------------------------------------------------------------------------
# FastAPI
# ---------------------------------------------------------------------------


http_client: httpx.AsyncClient
token_manager: TokenManager


@asynccontextmanager
async def lifespan(app: FastAPI):
    global http_client, token_manager
    http_client = build_http_client()
    token_manager = TokenManager(http_client)
    dump_path = Settings.DEBUG_DUMP_FILE or "(off)"
    log.info(
        "Proxy started -> %s%s (default model: %s, request dump: %s)",
        Settings.BASE_URL,
        Settings.API_PREFIX,
        Settings.DEFAULT_MODEL,
        dump_path,
    )
    log.info(
        "OpenClaw agent в логе: строки [chat]/[stream] (agent=...) из system "
        "«Runtime: agent=...»; полные тела — DEBUG_BODY=true или файл дампа выше"
    )
    try:
        yield
    finally:
        await http_client.aclose()
        log.info("Proxy stopped")


app = FastAPI(title="OpenAI->GigaChat adapter", lifespan=lifespan)


@app.get("/health")
async def health() -> dict[str, Any]:
    return {
        "status": "ok",
        "upstream": Settings.BASE_URL + Settings.API_PREFIX,
        "default_model": Settings.DEFAULT_MODEL,
        "mtls": {
            "cert": Settings.cert,
            "cert_exists": Path(Settings.cert).exists(),
            "key": Settings.key,
            "key_exists": Path(Settings.key).exists(),
            "verify_ssl": Settings.VERIFY_SSL,
            "root_ca": Settings.ROOT_CA,
        },
    }


@app.get("/")
async def root() -> dict[str, Any]:
    return {
        "service": "openai->gigachat adapter",
        "endpoints": ["/v1/models", "/v1/chat/completions", "/health"],
    }


async def _list_models_impl(request: Request) -> Response:
    """Возвращает список моделей в стандартном OpenAI-формате `/v1/models`.

    По умолчанию формирует ответ из `EXPOSED_MODELS` (наш кураторский список
    open-weights моделей через IFT) — IFT-апстрим для этого endpoint'а
    возвращает только GigaChat-* и не знает про новые id, так что
    проксировать его смысла нет. При `MODELS_FETCH_UPSTREAM=true` ещё и
    подмешивает upstream-список (для совместимости с GigaChat-* моделями).
    """
    _check_proxy_auth(request)

    now = int(time.time())
    seen: set[str] = set()
    data: list[dict[str, Any]] = []

    for model_id in Settings.exposed_models():
        if model_id in seen:
            continue
        seen.add(model_id)
        data.append({
            "id": model_id,
            "object": "model",
            "created": now,
            "owned_by": "ift-proxy",
        })

    if Settings.MODELS_FETCH_UPSTREAM:
        try:
            url = _gigachat_url("models")
            headers = await _build_outgoing_headers(request.headers.get("authorization"))
            resp = await http_client.get(url, headers=headers)
            if resp.status_code == 200:
                upstream = resp.json()
                for item in upstream.get("data", []) or []:
                    if not isinstance(item, dict):
                        continue
                    mid = item.get("id")
                    if not mid or mid in seen:
                        continue
                    seen.add(mid)
                    data.append({
                        "id": mid,
                        "object": "model",
                        "created": item.get("created", now),
                        "owned_by": item.get("owned_by", "gigachat"),
                    })
        except httpx.HTTPError as exc:
            log.warning("models upstream fetch failed (non-fatal): %s", exc)

    return JSONResponse({"object": "list", "data": data})


async def _chat_completions_impl(request: Request) -> Response:
    _check_proxy_auth(request)
    _request_id.set(uuid.uuid4().hex[:6])

    raw = await request.body()
    if not raw:
        raise HTTPException(status_code=400, detail="Empty body")
    try:
        body = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise HTTPException(status_code=400, detail=f"Invalid JSON: {exc}")

    # tool_result пишем из исходных messages ДО transform_request:
    # INLINE_TOOL_HISTORY превращает role=tool/function в user-текст,
    # и после transform их уже не найти.
    ctx_req = _openclaw_context_from_messages(body.get("messages"))
    for tr_name, tr_content in _detect_tool_results_in_messages(body.get("messages") or []):
        _write_tool_event(
            agent=ctx_req.get("agent") or "?",
            event="tool_result",
            tool=tr_name,
            detail=tr_content,
        )

    payload = transform_request(body)
    is_stream = bool(payload.get("stream"))

    url = _gigachat_url("chat/completions")
    headers = await _build_outgoing_headers(request.headers.get("authorization"))

    if Settings.PROXY_ACCESS_LOG:
        preview = _last_user_preview(payload.get("messages"))
        msgs = payload.get("messages") or []
        log.info(
            "[chat] agent=%s model=%s stream=%s msgs=%d prompt_chars=%d tools=%d user=%s",
            ctx_req.get("agent") or "?",
            payload.get("model"),
            is_stream,
            len(msgs),
            sum(len(_stringify_content(m.get("content"))) for m in msgs if isinstance(m, dict)),
            len(payload.get("tools") or payload.get("functions") or []),
            repr(preview) if preview else "-",
        )
    else:
        log.info(
            "chat/completions model=%s stream=%s tools=%s functions=%s tool_choice=%s msgs=%d",
            payload.get("model"),
            is_stream,
            bool(payload.get("tools")),
            bool(payload.get("functions")),
            payload.get("tool_choice") or payload.get("function_call"),
            len(payload.get("messages") or []),
        )
    if Settings.DEBUG_BODY:
        try:
            dump = json.dumps(payload, ensure_ascii=False)
        except Exception:
            dump = repr(payload)
        log.info("upstream <- %s", _truncate(dump))
    _dump_to_file("REQUEST -> upstream", payload)

    if is_stream:
        generator = _stream_chat(url, headers, payload)
        return StreamingResponse(
            generator,
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
                "X-Accel-Buffering": "no",
            },
        )

    resp = None
    last_net_exc: Optional[Exception] = None
    probe = _UpstreamProbe(f"agent={ctx_req.get('agent') or '?'} model={payload.get('model')}")
    probe.start_watch()
    try:
        for attempt in range(Settings.RETRY_NETWORK_MAX_ATTEMPTS + 1):
            try:
                resp = await http_client.post(url, headers=headers, json=payload)
                break
            except _NETWORK_RETRY_EXC as net_exc:
                last_net_exc = net_exc
                if attempt < Settings.RETRY_NETWORK_MAX_ATTEMPTS:
                    delay = Settings.RETRY_NETWORK_INITIAL_DELAY * (2 ** attempt)
                    log.warning(
                        "Upstream network error (%s) after %s; retry %d/%d in %.1fs",
                        type(net_exc).__name__,
                        probe.total(),
                        attempt + 1,
                        Settings.RETRY_NETWORK_MAX_ATTEMPTS,
                        delay,
                    )
                    _dump_to_file(
                        f"UPSTREAM NETWORK ERROR (will retry in {delay:.1f}s)",
                        f"{type(net_exc).__name__}: {net_exc}",
                    )
                    await asyncio.sleep(delay)
                    continue
                log.error(
                    "chat upstream network error after %d retries, %s: %s", attempt, probe.total(), net_exc
                )
                raise HTTPException(status_code=502, detail=f"Upstream unreachable: {net_exc}")
            except httpx.HTTPError as exc:
                log.error("chat upstream error after %s: %s", probe.total(), exc)
                raise HTTPException(status_code=502, detail=f"Upstream error: {exc}")
    finally:
        probe.stop_watch()
    if resp is not None:
        probe.on_headers(resp)

    if resp is None:
        raise HTTPException(status_code=502, detail=f"Upstream unreachable: {last_net_exc}")

    if resp.status_code >= 400:
        fallback = _with_fallback_model(payload) if _model_unavailable(resp.status_code, resp.text) else None
        if fallback is not None:
            log.warning(
                "Model %s unavailable (%s); answering with %s",
                payload.get("model"),
                resp.status_code,
                fallback["model"],
            )
            _dump_to_file("UPSTREAM MODEL MISSING (will retry)", resp.text)
            payload = fallback
            try:
                resp = await http_client.post(url, headers=headers, json=payload)
            except httpx.HTTPError as exc:
                log.error("fallback model error: %s", exc)
                raise HTTPException(status_code=502, detail=f"Upstream error: {exc}")
        if resp.status_code >= 400:
            log.error("Upstream %s after %s: %s", resp.status_code, probe.total(), _truncate(resp.text))
            _dump_to_file(f"UPSTREAM ERROR {resp.status_code}", resp.text)
            return JSONResponse(
                content={"error": {"message": resp.text, "code": resp.status_code}},
                status_code=resp.status_code,
            )

    try:
        raw_json = resp.json()
        _dump_to_file("RESPONSE <- upstream (raw)", raw_json)
        data = transform_response(raw_json)
        if Settings.DEBUG_BODY:
            log.info("upstream -> %s", _truncate(json.dumps(data, ensure_ascii=False)))
        if Settings.PROXY_ACCESS_LOG:
            choices = data.get("choices") if isinstance(data.get("choices"), list) else []
            ch0 = choices[0] if choices else {}
            msg = ch0.get("message") if isinstance(ch0, dict) else None
            fr = (ch0.get("finish_reason") if isinstance(ch0, dict) else None) or "-"
            tlist: list[str] = []
            if isinstance(msg, dict):
                for tc in msg.get("tool_calls") or []:
                    if not isinstance(tc, dict):
                        continue
                    fn = tc.get("function")
                    if isinstance(fn, dict) and fn.get("name"):
                        tlist.append(str(fn["name"]))
            probe.usage = raw_json.get("usage") if isinstance(raw_json, dict) else None
            log.info(
                "[response] %s status=%s total=%s finish=%s tools=%s tokens(in/out)=%s upstream_id=%s",
                probe.label,
                resp.status_code,
                probe.total(),
                fr,
                ",".join(tlist) if tlist else "-",
                probe.usage_str(),
                probe.upstream_id,
            )
        _dump_to_file("RESPONSE -> client (transformed)", data)
        return JSONResponse(content=data, status_code=resp.status_code)
    except json.JSONDecodeError:
        if Settings.DEBUG_BODY:
            log.info("upstream raw -> %s", _truncate(resp.text))
        _dump_to_file("RESPONSE <- upstream (text)", resp.text)
        return Response(
            content=resp.content,
            status_code=resp.status_code,
            media_type=resp.headers.get("content-type", "application/json"),
        )


@app.get("/v1/models")
async def v1_models(request: Request) -> Response:
    return await _list_models_impl(request)


@app.get("/models")
async def models_alias(request: Request) -> Response:
    return await _list_models_impl(request)


@app.post("/v1/chat/completions")
async def v1_chat_completions(request: Request) -> Response:
    return await _chat_completions_impl(request)


@app.post("/chat/completions")
async def chat_completions_alias(request: Request) -> Response:
    return await _chat_completions_impl(request)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="OpenAI->GigaChat proxy for OpenClaw-like clients")
    p.add_argument("--host", default=os.getenv("HOST", "127.0.0.1"))
    p.add_argument("--port", type=int, default=int(os.getenv("PORT", "9111")))
    p.add_argument("--log-level", default=os.getenv("LOG_LEVEL", "info"))
    return p.parse_args()


def main() -> None:
    args = parse_args()
    uvicorn.run(app, host=args.host, port=args.port, log_level=args.log_level)


if __name__ == "__main__":
    main()
