import uuid

import streamlit as st


def reset_to_zero_input_pipeline() -> None:
    st.session_state.user_input = None


def reset_to_zero_products_pipeline() -> None:
    # products
    st.session_state.show_selectbox_products = False
    st.session_state.selectbox_key_products = None
    st.session_state.products_list = None
    st.session_state.selected_product = None
    st.session_state.selectbox_key_products = str(uuid.uuid4())


def reset_to_zero_fx_pipeline() -> None:
    st.session_state.show_selectbox_fx = False
    st.session_state.selected_option_fx = None
    st.session_state.fx_list = None
    st.session_state.selectbox_key_fx = str(uuid.uuid4())
    st.session_state.show_selectbox_fx_period = False
    st.session_state.fx_list_period = None
    st.session_state.selected_option_fx_period = None
    st.session_state.selectbox_key_fx_period = str(uuid.uuid4())
    st.session_state.start_period_pipeline = False
    st.session_state.show_fx_period = False


def reset_to_zero_pers_pipeline() -> None:
    st.session_state.show_selectbox_pers = False
    st.session_state.selected_option_pers = None
    st.session_state.pers_list = None
    st.session_state.selectbox_key_pers = str(uuid.uuid4())
    st.session_state.show_selectbox_pers_period = False
    st.session_state.pers_list_period = None
    st.session_state.selected_option_pers_period = None
    st.session_state.selectbox_key_pers_period = str(uuid.uuid4())
    st.session_state.start_period_pipeline = False
    st.session_state.show_pers_period = False
    st.session_state.DO_PERS = False
    st.session_state.ADDITIONAL_INSTRUCTION = ""
    st.session_state.exec_personification_pipeline = False
    st.session_state.personification_scenario = None
    st.session_state.personification_seeded_scenario = None


def reset_to_zero_cmdt_pipeline() -> None:
    st.session_state.show_selectbox_cmdt = False
    st.session_state.selected_option_cmdt = None
    st.session_state.cmdt_list = None
    st.session_state.selectbox_key_cmdt = str(uuid.uuid4())
    st.session_state.show_selectbox_cmdt_period = False
    st.session_state.cmdt_list_period = None
    st.session_state.selected_option_cmdt_period = None
    st.session_state.selectbox_key_cmdt_period = str(uuid.uuid4())
    st.session_state.start_period_pipeline = False
    st.session_state.show_cmdt_period = False


def reset_to_zero_indicatives_pipeline() -> None:
    st.session_state.products_list_ind = None
    st.session_state.button_key_ind_products = str(uuid.uuid4())
    st.session_state.ind_product = None
    st.session_state.start_ind_pipe_product = False
    st.session_state.show_indicatives_button_1 = False
    st.session_state.indicatives_df_fx_options = None
    st.session_state.indicatives_file_modification_date = None
    st.session_state.button_values_ind_type = None
    st.session_state.ind_full_response_d = None
    st.session_state.selected_btn_ind_type = None
    st.session_state.button_key_indicatives_type = str(uuid.uuid4())
    st.session_state.start_indicatives_tenor = False
    st.session_state.selected_btn_ind_tenor = None
    st.session_state.button_key_indicatives_tenor = str(uuid.uuid4())
    st.session_state.start_indicatives_strike = False
    st.session_state.button_key_indicatives_strike = str(uuid.uuid4())
    st.session_state.btn_ind_strike = None
    st.session_state.indicatives_finish = False
    st.session_state.button_values_ind_tenor = None
    st.session_state.button_values_ind_strike = None


def reset_to_zero_potential_pipeline() -> None:
    st.session_state.selected_company = None
    st.session_state.selectbox_key_potential_holdings = str(uuid.uuid4())
    st.session_state.selectbox_key_potential_holdings_with_similar_companies = str(uuid.uuid4())
    st.session_state.selectbox_key_potential_stand_alone_companies = str(uuid.uuid4())
    st.session_state.potential_df = None
    st.session_state.most_similar_holdings = None
    st.session_state.most_similar_stand_alones = None
    st.session_state.holdings_with_similar_companies = None
    st.session_state.show_first_selectboxes = False
    st.session_state.holding = None
    st.session_state.holding_with_similar_companies = None
    st.session_state.stand_alone_company = None
    st.session_state.show_potential_df_holding = False
    st.session_state.show_potential_df_stand_alone = False
    st.session_state.potential_table = None
    st.session_state.companies_in_holdings_list = None
    st.session_state.selectbox_key_potential_companies_from_holding = str(uuid.uuid4())
    st.session_state.show_potential_df_company_from_holding = False


def reset_to_zero_sales_pipeline() -> None:
    st.session_state.button_products_sales = None
    st.session_state.selected_sales_product = None
    st.session_state.button_key_sales_products = str(uuid.uuid4())
    st.session_state.binary_button_values_1 = None
    st.session_state.product_sales_description = None
    st.session_state.sales_binary_btn_1 = None
    st.session_state.button_key_sales_binary_1 = str(uuid.uuid4())
    st.session_state.binary_button_values_2 = None
    st.session_state.button_key_sales_binary_2 = str(uuid.uuid4())
    st.session_state.sales_binary_btn_2 = None
    st.session_state.selected_sales_binary_answer_2 = None
    st.session_state.sales_button_values_ind_type = None
    st.session_state.start_sales_indicatives = False
    st.session_state.sales_button_values_ind_type = None
    st.session_state.start_sales_indicatives = False
    st.session_state.sales_start_indicatives_tenor = None
    st.session_state.sales_button_values_ind_tenor = None
    st.session_state.sales_start_indicatives_strike = False
    st.session_state.sales_button_values_ind_strike = None
    st.session_state.sales_indicatives_finish = False
    st.session_state.sales_ind_full_response_d = None
    st.session_state.binary_button_values_3 = None
    st.session_state.start_alternative_pipeline = False
    st.session_state.button_values_alt = None
    st.session_state.btn_alt = None
    st.session_state.button_key_sales_products_alt = str(uuid.uuid4())
    st.session_state.binary_button_values_1_alt = None
    st.session_state.sales_alt_description = None
    st.session_state.binary_button_values_2_alt = None
    st.session_state.button_key_sales_binary_2_alt = str(uuid.uuid4())
    st.session_state.binary_btn_2_alt = None
    st.session_state.indicatives_pipeline_alt = False
    st.session_state.not_interested_user_input = None
    st.session_state.saled_user_input = None
    st.session_state.indicatives_pipeline_alt = None
    st.session_state.sales_alt_button_values_ind_type = None
    st.session_state.sales_alt_start_indicatives_tenor = None
    st.session_state.sales_alt_button_values_ind_tenor = None
    st.session_state.sales_alt_start_indicatives_strike = None
    st.session_state.sales_alt_button_values_ind_strike = None
    st.session_state.sales_alt_indicatives_finish = None
    st.session_state.sales_alt_ind_full_response_d = None
    st.session_state.binary_button_values_3_alt = None
    st.session_state.selected_sales_binary_answer_3 = None


def reset_to_zero_calls_pipeline() -> None:
    if "calls_mode" in st.session_state:
        st.session_state.calls_mode = False
    if "calls_data_loaded" in st.session_state:
        st.session_state.calls_data_loaded = False
    if "calls_retriever" in st.session_state:
        st.session_state.calls_retriever = None
    # Всегда создаём ключ: иначе append в write_call_table_answer / write_calls падает (например, первый клик по /calls_tb в сайдбаре).
    st.session_state.calls_chat_history = []
    if "call_table_interactive_ctx" in st.session_state:
        del st.session_state["call_table_interactive_ctx"]


def reset_to_zero_market_pipeline() -> None:
    st.session_state.show_market_choice = False
    st.session_state.market_combined_list = None
    st.session_state.selectbox_key_market = str(uuid.uuid4())


def reset_to_zero_notes_pipeline() -> None:
    # Каноническая реализация — notes_engine (без дублирования ключей).
    from synaptica.backend.streamlit_functions.notes_engine import (
        reset_to_zero_notes_pipeline as _notes_reset,
    )
    _notes_reset()


def reset_to_zero_presentation_gen_pipeline() -> None:
    if "presentation_gen_mode" in st.session_state:
        st.session_state.presentation_gen_mode = False
    if "presentation_gen_chat_history" in st.session_state:
        st.session_state.presentation_gen_chat_history = []


def reset_to_zero_logs_view_pipeline() -> None:
    if "logs_view_mode" in st.session_state:
        st.session_state.logs_view_mode = False
    if "logs_view_chat_history" in st.session_state:
        st.session_state.logs_view_chat_history = []
    if "comments_last_query" in st.session_state:
        st.session_state.comments_last_query = None
    if "comments_last_filters" in st.session_state:
        st.session_state.comments_last_filters = None


def reset_to_zero_call_upload_pipeline() -> None:
    if "call_upload_mode" in st.session_state:
        st.session_state.call_upload_mode = False
    if "call_upload_chat_history" in st.session_state:
        st.session_state.call_upload_chat_history = []
    st.session_state.call_upload_uploader_key = f"cu_{uuid.uuid4().hex[:8]}"


def reset_to_zero_special_news_pipeline() -> None:
    if "special_news_mode" in st.session_state:
        st.session_state.special_news_mode = False
    if "special_news_chat_history" in st.session_state:
        st.session_state.special_news_chat_history = []
    for k in (
        "sn_menu",
        "sn_edit_company",
        "sn_edit_industry",
        "sn_prefs",
        "sn_prefs_user",
    ):
        st.session_state.pop(k, None)


def reset_to_zero_openclaw_pipeline() -> None:
    for mode_key, hist_key, agent_id in [
        ("openclaw_coder_mode", "openclaw_coder_chat_history", "synaptica-coder"),
        ("openclaw_helper_mode", "openclaw_helper_chat_history", "synaptica-helper"),
        ("openclaw_client_mode", "openclaw_client_chat_history", "client-helper"),
        ("openclaw_fi_sales_mode", "openclaw_fi_sales_chat_history", "fi-sales"),
        ("openclaw_corp_sales_mode", "openclaw_corp_sales_chat_history", "corp-sales"),
        ("openclaw_calls_mode", "openclaw_calls_chat_history", "calls"),
        ("openclaw_pres_gen_mode", "openclaw_pres_gen_chat_history", "pres-gen"),
        ("openclaw_rates_pricing_mode", "openclaw_rates_pricing_chat_history", "rates-pricing"),
        ("openclaw_products_mode", "openclaw_products_chat_history", "products-rag"),
    ]:
        if mode_key in st.session_state:
            st.session_state[mode_key] = False
        if hist_key in st.session_state:
            st.session_state[hist_key] = []
        st.session_state.pop(f"openclaw_{agent_id}_response_id", None)
    st.session_state.pop("fi_notes_table_ctx", None)
    st.session_state.pop("corp_notes_table_ctx", None)
    st.session_state.pop("notes_list_ctx", None)
    st.session_state.pop("notes_edit_id", None)
    st.session_state.pop("notes_edit_flash", None)
    st.session_state.pop("notes_structured_draft", None)
    st.session_state.pop("_notes_draft_pending_rerun", None)
    st.session_state.client_file_uploader_key = f"cfu_{uuid.uuid4().hex[:8]}"


def reset_to_zero_openclaw_vnd_rag_pipeline() -> None:
    st.session_state["openclaw_vnd_rag_mode"] = False
    st.session_state["openclaw_vnd_rag_chat_history"] = []
    st.session_state["openclaw_vnd_rag_multi_doc"] = False


def reset_to_zero_openclaw_router_pipeline() -> None:
    st.session_state["openclaw_router_mode"] = False
    st.session_state["openclaw_router_chat_history"] = []
    st.session_state.pop("openclaw_synaptica-router_response_id", None)
    st.session_state.pop("openclaw_routing", None)


def reset_to_zero_optimizer_pipeline() -> None:
    st.session_state["optimizer_mode"] = False
    st.session_state.pop("optimizer_last_result", None)


def reset_to_zero_broker_pipeline() -> None:
    from synaptica.backend.streamlit_functions.broker_engine import (
        reset_to_zero_broker_pipeline as _broker_reset,
    )
    _broker_reset()


def reset_to_zero_ALL_pipelines() -> None:
    reset_to_zero_input_pipeline()
    reset_to_zero_products_pipeline()
    reset_to_zero_fx_pipeline()
    reset_to_zero_pers_pipeline()
    reset_to_zero_cmdt_pipeline()
    reset_to_zero_indicatives_pipeline()
    reset_to_zero_potential_pipeline()
    reset_to_zero_sales_pipeline()
    reset_to_zero_calls_pipeline()
    reset_to_zero_notes_pipeline()
    reset_to_zero_market_pipeline()
    reset_to_zero_openclaw_pipeline()
    reset_to_zero_openclaw_vnd_rag_pipeline()
    reset_to_zero_openclaw_router_pipeline()
    reset_to_zero_presentation_gen_pipeline()
    reset_to_zero_logs_view_pipeline()
    reset_to_zero_call_upload_pipeline()
    reset_to_zero_special_news_pipeline()
    reset_to_zero_optimizer_pipeline()
    reset_to_zero_broker_pipeline()
