"""Ordinary field examples and a button copying an empty notes template."""
from __future__ import annotations

import html
import json
import re

from synaptica.backend.streamlit_functions.notes_draft import strip_draft_marker


_EXAMPLES = re.compile(r"<!--\s*NOTES_EXAMPLES\s+([\s\S]*?)-->", re.IGNORECASE)
_FIELDS = re.compile(r"<!--\s*NOTES_FIELDS\s+([\s\S]*?)-->", re.IGNORECASE)
_FIELD_LABELS = frozenset({
    "дата", "дата встречи", "время начала", "время окончания", "время конца",
    "длительность", "продолжительность", "тип", "тип встречи", "контрагент", "клиент",
    "участники", "участники со стороны банка", "участники со стороны клиента",
    "ключевые моменты", "суть", "текст заметки", "продукт", "финансовый продукт", "валюта", "валюты",
})


def strip_notes_internal(text: str, *, notes_mode: bool = True) -> str:
    text = strip_draft_marker(text, include_unmarked=notes_mode)
    text = re.sub(r"(?:<!--|&lt;!--)\s*NOTES_(?:EXAMPLES|FIELDS)\s+[\s\S]*?(?:-->|--&gt;)", "", text, flags=re.IGNORECASE)
    text = re.sub(r"(?:<!--|&lt;!--)\s*NOTES_(?:EXAMPLES|FIELDS)[\s\S]*$", "", text, flags=re.IGNORECASE)
    for marker in list(re.finditer(r"\bNOTES_(?:EXAMPLES|FIELDS)\s*:?\s*", text, re.IGNORECASE))[::-1]:
        rest = text[marker.end():]
        try:
            _, end = json.JSONDecoder().raw_decode(rest)
        except ValueError:
            end = len(rest)
        text = text[:marker.start()] + rest[end:]
    text = re.sub(r"\x60\x60\x60(?:json)?\s*\x60\x60\x60", "", text, flags=re.IGNORECASE)
    return text.strip()


def notes_examples_html(response: str) -> str:
    """Old history keeps its examples, now as ordinary selectable text."""
    items = []
    for match in _EXAMPLES.finditer(response or ""):
        try:
            data = json.loads(match.group(1))
        except (ValueError, TypeError):
            continue
        if not isinstance(data, dict) or not isinstance(data.get("items"), list):
            continue
        for item in data["items"][:24]:
            if not isinstance(item, dict):
                continue
            field, example = item.get("field"), item.get("example")
            if isinstance(field, str) and isinstance(example, str) and field.strip() and example.strip():
                field = html.escape(field.strip()[:100])
                example = html.escape(example.strip()[:500])
                items.append(f"<div><strong>{field}:</strong> <span>{example}</span></div>")
    return '<div class="notes-field-examples">' + "".join(items) + "</div>" if items else ""


def _field_label(value) -> str:
    if not isinstance(value, str):
        return ""
    name = re.sub(r"^\s*(?:[-*]|\d+[.)])\s*", "", value).replace("*", "").replace(chr(96), "")
    name = re.sub(r"\([^)]*\)", "", name).split(":", 1)[0].strip()
    return name if name.casefold() in _FIELD_LABELS else ""


def notes_fields_template(response: str) -> str:
    """Only labels enter the clipboard; examples and actual values never do."""
    fields = []
    for match in _FIELDS.finditer(response or ""):
        try:
            data = json.loads(match.group(1))
        except (ValueError, TypeError):
            continue
        if isinstance(data, dict) and isinstance(data.get("fields"), list):
            fields.extend(data["fields"])
    if not fields:
        # Compatibility with empty field blocks from previous responses.
        for block in re.findall(r"\x60\x60\x60(?:text|plaintext)?\s*\n([\s\S]*?)\x60\x60\x60", response or ""):
            fields.extend(line for line in block.splitlines() if re.search(r":\s*$", line))
    if not fields:
        for match in _EXAMPLES.finditer(response or ""):
            try:
                data = json.loads(match.group(1))
            except (ValueError, TypeError):
                continue
            if isinstance(data, dict) and isinstance(data.get("items"), list):
                fields.extend(item.get("field") for item in data["items"] if isinstance(item, dict))
    labels, seen = [], set()
    for value in fields:
        label = _field_label(value)
        if label and label.casefold() not in seen:
            labels.append(label)
            seen.add(label.casefold())
    return "\n".join(f"{label}: " for label in labels)


def notes_copy_button_html(template: str) -> str:
    """Copy on a user click, supporting HTTPS clipboard and HTTP fallback."""
    if not template:
        return ""
    value = html.escape(template, quote=True)
    return '''<!doctype html><html><head><meta charset="utf-8">
<style>
body{margin:0;font:14px system-ui,sans-serif;color:#31333f}
button{font:inherit;color:inherit;background:#fff;border:1px solid #c8ccd2;border-radius:8px;padding:7px 12px;cursor:pointer}
button:hover{border-color:#16825d}button:focus-visible{outline:2px solid #16825d;outline-offset:2px}
#copy-status{font-size:12px;line-height:18px;margin-top:4px}
textarea{position:fixed;left:-10000px;top:0;width:400px;height:200px}
@media(prefers-color-scheme:dark){body{color:#fafafa}button{background:#262730;border-color:#555}}
</style></head><body>
<button type="button" id="copy-fields">Скопировать поля</button>
<div id="copy-status" role="status" aria-live="polite"></div>
<textarea id="fields-template" readonly tabindex="-1" aria-hidden="true">''' + value + '''</textarea>
<script>
const button = document.getElementById("copy-fields");
const template = document.getElementById("fields-template");
const status = document.getElementById("copy-status");
let resetTimer;
function legacyCopy() {
  template.focus();
  template.select();
  template.setSelectionRange(0, template.value.length);
  return document.execCommand("copy");
}
button.addEventListener("click", async () => {
  button.disabled = true;
  status.textContent = "";
  button.textContent = "Скопировать поля";
  clearTimeout(resetTimer);
  let copied = false;
  try {
    if (window.isSecureContext && navigator.clipboard && navigator.clipboard.writeText) {
      try {
        await navigator.clipboard.writeText(template.value);
        copied = true;
      } catch (_) {
        copied = legacyCopy();
      }
    } else {
      copied = legacyCopy();
    }
  } catch (_) {
    copied = false;
  }
  button.disabled = false;
  if (copied) {
    button.textContent = "Поля скопированы";
    button.focus();
    resetTimer = setTimeout(() => { button.textContent = "Скопировать поля"; }, 2000);
  } else {
    status.textContent = "Не удалось скопировать автоматически. Нажмите Ctrl+C / Cmd+C.";
  }
});
</script></body></html>'''


def render_notes_examples(response: str) -> None:
    """Existing UI hook for history, the welcome message and live answers."""
    content = notes_examples_html(response)
    if content:
        import streamlit as st
        st.markdown(content, unsafe_allow_html=True)
    template = notes_fields_template(response)
    if template:
        import streamlit.components.v1 as components
        components.html(notes_copy_button_html(template), height=82, scrolling=False)
