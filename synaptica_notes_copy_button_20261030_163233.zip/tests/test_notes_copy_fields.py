"""Clipboard payload and safe rendering for copyable empty notes fields."""
from __future__ import annotations

import json
import sys
import unittest
from html.parser import HTMLParser
from types import ModuleType
from unittest.mock import Mock, patch

from notes_test_support import notes_presentation as presentation


def fields_marker(fields):
    return '<!-- NOTES_FIELDS ' + json.dumps({"fields": fields}, ensure_ascii=False) + ' -->'


class TextareaValue(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.in_textarea = False
        self.parts = []
        self.scripts = 0

    def handle_starttag(self, tag, attrs):
        if tag == "textarea":
            self.in_textarea = True
        if tag == "script":
            self.scripts += 1

    def handle_endtag(self, tag):
        if tag == "textarea":
            self.in_textarea = False

    def handle_data(self, data):
        if self.in_textarea:
            self.parts.append(data)


class NotesCopyFieldsTests(unittest.TestCase):
    def test_copy_contains_empty_labels_on_separate_real_lines(self):
        response = "- Дата: (например, вчера)\n- Время начала: (16:30)\n- Длительность: (45 минут)\n"
        response += fields_marker(["Дата", "Время начала", "Длительность"])
        self.assertEqual(presentation.notes_fields_template(response),
                         "Дата: \nВремя начала: \nДлительность: ")
        self.assertIn("вчера", presentation.strip_notes_internal(response))
        self.assertNotIn("NOTES_FIELDS", presentation.strip_notes_internal(response))

    def test_metadata_never_copies_examples_values_or_duplicate_labels(self):
        response = fields_marker(["Дата: вчера", "дата", "**Время начала** (например, 16:30)",
                                  {"field": "Тип"}, "служебный_токен", "Длительность: 45 минут"])
        self.assertEqual(presentation.notes_fields_template(response),
                         "Дата: \nВремя начала: \nДлительность: ")

    def test_old_history_still_provides_copyable_template(self):
        fence = chr(96) * 3
        old = fence + "text\nДата:\nВремя начала:\n" + fence
        self.assertEqual(presentation.notes_fields_template(old), "Дата: \nВремя начала: ")
        old = '<!-- NOTES_EXAMPLES {"items":[{"field":"Дата","example":"вчера"},{"field":"Тип","example":"встреча"}]} -->'
        self.assertEqual(presentation.notes_fields_template(old), "Дата: \nТип: ")
        self.assertIn("вчера", presentation.notes_examples_html(old))

    def test_real_confirmation_is_not_treated_as_blank_fields(self):
        response = "1. Дата: 13 октября\n2. Время начала: 16:30\nВерно?"
        self.assertEqual(presentation.notes_fields_template(response), "")
        self.assertEqual(presentation.notes_copy_button_html(""), "")
        self.assertEqual(presentation.strip_notes_internal(response), response)

    def test_button_embeds_exact_multiline_payload_and_escapes_markup(self):
        template = "Дата: \nВремя начала: \n</textarea><script>bad()</script>&"
        content = presentation.notes_copy_button_html(template)
        parser = TextareaValue()
        parser.feed(content)
        self.assertEqual("".join(parser.parts), template)
        self.assertEqual(parser.scripts, 1)
        self.assertIn("Скопировать поля", content)
        self.assertNotIn("<script>bad()", content)

    def test_malformed_or_partial_field_markers_are_hidden(self):
        for raw in ('<!-- NOTES_FIELDS {"fields":["Дата"', '<!-- NOTES_FIELDS {bad} -->',
                    '&lt;!-- NOTES_FIELDS {"fields":["Дата"]} --&gt;'):
            self.assertEqual(presentation.strip_notes_internal("Заполни дату.\n" + raw), "Заполни дату.")

    def test_renderer_adds_copy_button_via_existing_streamlit_component(self):
        st = ModuleType("streamlit")
        st.__path__ = []
        st.markdown = Mock()
        package = ModuleType("streamlit.components")
        package.__path__ = []
        components = ModuleType("streamlit.components.v1")
        components.html = Mock()
        st.components = package
        package.v1 = components
        with patch.dict(sys.modules, {"streamlit": st, "streamlit.components": package,
                                      "streamlit.components.v1": components}):
            presentation.render_notes_examples(fields_marker(["Дата", "Длительность"]))
        st.markdown.assert_not_called()
        components.html.assert_called_once()
        self.assertEqual(components.html.call_args.kwargs, {"height": 82, "scrolling": False})
        parser = TextareaValue()
        parser.feed(components.html.call_args.args[0])
        self.assertEqual("".join(parser.parts), "Дата: \nДлительность: ")


if __name__ == "__main__":
    unittest.main()
