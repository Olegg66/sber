/* Run with: node synaptica/tests/test_notes_copy_button.cjs */
const vm = require("node:vm");
const assert = require("node:assert/strict");
const fs = require("node:fs");
const path = require("node:path");

async function main() {
  const root = path.resolve(__dirname, "..");
  const source = [
    path.join(root, "backend", "streamlit_functions", "notes_presentation.py"),
    path.join(root, "backend", "backend", "streamlit_functions", "notes_presentation.py"),
  ].find(name => fs.existsSync(name));
  const script = fs.readFileSync(source, "utf8").match(/<script>\r?\n([\s\S]*?)\r?\n<\/script>/)[1];
  const expected = "Дата: \nВремя начала: \nДлительность: ";
  function setup(opts = {}) {
    const calls = {native: [], legacy: [], selected: 0, focus: 0, selection: [], timers: []};
    const template = {
      value: expected, focus() {calls.focus++}, select() {calls.selected++},
      setSelectionRange(a, b) {calls.selection = [a, b]},
    };
    const button = {
      disabled: false, textContent: "Скопировать поля", focus() {},
      addEventListener(event, cb) {assert.equal(event, "click"); this.click = cb},
    };
    const status = {textContent: ""};
    const nodes = {"copy-fields": button, "fields-template": template, "copy-status": status};
    const document = {
      getElementById(id) {return nodes[id]},
      execCommand(command) {
        calls.legacy.push(command);
        if (opts.legacyThrows) throw Error("denied");
        return opts.legacy !== false;
      },
    };
    const navigator = {
      clipboard: opts.missing ? undefined : {
        async writeText(value) {
          calls.native.push(value);
          if (opts.denied) throw Error("denied");
        },
      },
    };
    vm.runInNewContext(script, {
      document, window: {isSecureContext: opts.secure !== false}, navigator,
      setTimeout(cb) {calls.timers.push(cb); return calls.timers.length}, clearTimeout() {},
    });
    return {calls, template, button, status, opts};
  }
  let page = setup();
  assert.deepEqual(page.calls.native, []);
  assert.deepEqual(page.calls.legacy, []);
  await page.button.click();
  assert.deepEqual(page.calls.native, [expected]);
  assert.deepEqual(page.calls.legacy, []);
  assert.equal(page.button.disabled, false);
  assert.equal(page.button.textContent, "Поля скопированы");
  page.calls.timers[0]();
  assert.equal(page.button.textContent, "Скопировать поля");
  for (const opts of [{secure: false}, {missing: true}, {denied: true}]) {
    page = setup(opts);
    await page.button.click();
    assert.deepEqual(page.calls.legacy, ["copy"]);
    assert.equal(page.calls.selected, 1);
    assert.deepEqual(page.calls.selection, [0, expected.length]);
    assert.equal(page.template.value, expected);
    assert.equal(page.button.textContent, "Поля скопированы");
  }
  for (const opts of [{denied: true, legacy: false}, {secure: false, legacyThrows: true}]) {
    page = setup(opts);
    await page.button.click();
    assert.equal(page.button.disabled, false);
    assert.equal(page.button.textContent, "Скопировать поля");
    assert.match(page.status.textContent, /Не удалось/);
    assert.equal(page.calls.timers.length, 0);
  }
  page = setup();
  await page.button.click();
  page.opts.denied = true;
  page.opts.legacy = false;
  await page.button.click();
  assert.equal(page.button.textContent, "Скопировать поля");
  assert.match(page.status.textContent, /Не удалось/);
  return {cases: 7, passed: true};
}
module.exports = main;
if (require.main === module) {
  main().then(result => console.log(JSON.stringify(result))).catch(error => {
    console.error(error);
    process.exitCode = 1;
  });
}
