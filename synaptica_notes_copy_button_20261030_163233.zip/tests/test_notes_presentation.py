"""Copyable field templates, private draft rendering and optional client people."""
from __future__ import annotations

import ast
import json
import unittest
from html.parser import HTMLParser
from types import SimpleNamespace
from unittest.mock import Mock

from notes_test_support import load_pure_module, notes_draft, repo_path


presentation = load_pure_module(
    "synaptica.backend.streamlit_functions.notes_presentation",
    "backend/streamlit_functions/notes_presentation.py",
)


class VisibleDOMText(HTMLParser):
    def __init__(self):
        super().__init__()
        self.parts = []
        self.in_style = False

    def handle_starttag(self, tag, attrs):
        if tag == "style":
            self.in_style = True

    def handle_endtag(self, tag):
        if tag == "style":
            self.in_style = False

    def handle_data(self, data):
        if not self.in_style:
            self.parts.append(data)


class NotesPresentationTests(unittest.TestCase):
    def test_welcome_examples_are_visible_and_copy_payload_has_only_empty_fields(self):
        tree = ast.parse(repo_path("backend/streamlit_functions/st_functions.py").read_text(encoding="utf-8"))
        welcome_node = next(node for node in tree.body if isinstance(node, ast.Assign) and
                            any(isinstance(t, ast.Name) and t.id == "FI_NOTES_WELCOME" for t in node.targets))
        welcome = ast.literal_eval(welcome_node.value)
        visible = presentation.strip_notes_internal(welcome)
        self.assertIn("ВТБ", visible)
        self.assertIn("11:00", visible)
        self.assertIn("вчера; 22 сентября", visible)
        self.assertNotIn("NOTES_FIELDS", visible)
        self.assertNotIn("NOTES_EXAMPLES", welcome)
        template = presentation.notes_fields_template(welcome)
        self.assertEqual(template.splitlines(), ["Дата: ", "Время начала: ", "Длительность: ", "Тип: ",
                                                 "Контрагент: ", "Участники со стороны банка: ", "Ключевые моменты: "])
        self.assertNotIn("ВТБ", template)
        self.assertNotIn("11:00", template)
        self.assertNotIn("**", template)

    def test_legacy_examples_are_normal_selectable_text_and_escape_model_values(self):
        response = '<!-- NOTES_EXAMPLES ' + json.dumps({"items": [
            {"field": "Дата", "example": "28 октября"},
            {"field": "Клиент", "example": '<script>alert("bad")</script>'},
        ]}, ensure_ascii=False) + ' -->'
        content = presentation.notes_examples_html(response)
        parser = VisibleDOMText()
        parser.feed(content)
        self.assertIn("28 октября", "".join(parser.parts))
        self.assertNotIn("user-select:none", content)
        self.assertNotIn("data-hint=", content)
        self.assertNotIn("<script>", content)
        self.assertIn("&lt;script&gt;", content)

    def test_internal_json_is_hidden_for_normal_escaped_fenced_and_bare_directives(self):
        data = '{"action":"update","fields":{"raw_text":"PRIVATE INTERNAL STATE"}}'
        variants = [
            '<!-- NOTES_DRAFT ' + data + ' -->',
            '&lt;!-- NOTES_DRAFT ' + data + ' --&gt;',
            '```json\n' + data + '\n```',
            '```json\n<!-- NOTES_DRAFT ' + data + ' -->\n```',
            'NOTES_DRAFT: ' + data,
            'notes_draft: ' + data,
        ]
        for fragment in variants:
            with self.subTest(fragment=fragment):
                cleaned = presentation.strip_notes_internal("Кто был со стороны банка?\n" + fragment)
                self.assertEqual(cleaned, "Кто был со стороны банка?")

    def test_partial_stream_never_exposes_draft_values_or_example_metadata(self):
        fragments = [
            '<!-- NOTES_DRAFT {"fields":{"raw_text":"PRIVATE',
            '```json\n{"action":"update","fields":{"raw_text":"PRIVATE',
            '&lt;!-- NOTES_DRAFT {"fields":{"raw_text":"PRIVATE',
            'NOTES_DRAFT {"fields":{"raw_text":"PRIVATE',
            '<!-- NOTES_EXAMPLES {"items":[{"field":"Дата","example":"EXAMPLE',
        ]
        for fragment in fragments:
            self.assertEqual(presentation.strip_notes_internal("Укажи время.\n" + fragment), "Укажи время.")

    def test_actual_preview_values_remain_visible(self):
        preview = "1. Дата: 13 октября\n2. Длительность: 45 минут\n3. Контрагент: ВТБ\nВерно?"
        self.assertEqual(presentation.strip_notes_internal(preview), preview)

    def test_application_never_calls_draft_form(self):
        tree = ast.parse(repo_path("synaptica_app.py").read_text(encoding="utf-8"))
        names = {node.func.id for node in ast.walk(tree) if isinstance(node, ast.Call)
                 and isinstance(node.func, ast.Name)}
        self.assertNotIn("render_notes_draft_panel", names)
        self.assertNotIn("render_draft_form", names)

    def test_draft_retains_client_people_separately_and_currency_specific_sides(self):
        draft = notes_draft.merge_draft({}, {"fields": {
            "date": "2026-10-13", "meeting_duration": "45 минут",
            "participants": ["Скрипников Роман Игоревич"],
            "client_participants": ["Иван Петров, казначей ВТБ"],
            "trade_sides": [{"currency": "CNY", "side": "client_buys"}],
        }}, "riskripnikov", "fi")
        draft = notes_draft.merge_draft(draft, {"fields": {
            "client_canonical": "ВТБ", "client_participants": [],
            "trade_sides": [{"currency": "USD", "side": "client_sells"}],
        }}, "riskripnikov", "fi")
        fields = draft["fields"]
        self.assertEqual(fields["participants"], ["Скрипников Роман Игоревич"])
        self.assertEqual(fields["client_participants"], ["Иван Петров, казначей ВТБ"])
        self.assertEqual(fields["date"], "2026-10-13")
        self.assertEqual(fields["trade_sides"], [{"currency": "CNY", "side": "client_buys"},
                                                 {"currency": "USD", "side": "client_sells"}])

    def test_card_mapping_keeps_client_people_and_card_does_not_grant_access(self):
        from test_notes_saved_cards import ui_namespace, saved_record

        namespace = ui_namespace()
        record = saved_record()
        record["client_participants"] = ["Петров Пётр, ВТБ"]
        card = namespace["_notes_card_record"](record)
        self.assertEqual(card["client_participants"], ["Петров Пётр, ВТБ"])
        namespace["_notes_can_edit"] = Mock(return_value=False)
        namespace["_render_notes_record_cards"]([card], "fi", "")
        html = namespace["st"].markdown.call_args.args[0]
        self.assertIn("Участники со стороны клиента", html)
        self.assertIn("Петров Пётр", html)
        self.assertEqual(card["editors"], record["editors"])
        self.assertNotIn("Петров Пётр, ВТБ", card["participants"])


if __name__ == "__main__":
    unittest.main()
